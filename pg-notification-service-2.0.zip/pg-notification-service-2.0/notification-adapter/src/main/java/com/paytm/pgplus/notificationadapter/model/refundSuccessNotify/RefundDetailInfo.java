package com.paytm.pgplus.notificationadapter.model.refundSuccessNotify;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pgplus.notificationadapter.model.Money;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RefundDetailInfo implements Serializable {

    /** serialVersionUID */
    private static final long serialVersionUID = 1L;

    /**
     * channel information
     */
    private List<RefundChannelInfo> channelInfoList;

    private String destination;

    @NotNull(message = "{not null}")
    private Money refundDetailAmount;

    private String refundDestinationSwitchReason;

    public String getRefundDestinationSwitchReason() {
        return refundDestinationSwitchReason;
    }

    public void setRefundDestinationSwitchReason(String refundDestinationSwitchReason) {
        this.refundDestinationSwitchReason = refundDestinationSwitchReason;
    }

    public List<RefundChannelInfo> getChannelInfoList() {
        return channelInfoList;
    }

    public void setChannelInfoList(List<RefundChannelInfo> channelInfoList) {
        this.channelInfoList = channelInfoList;
    }

    public Money getRefundDetailAmount() {
        return refundDetailAmount;
    }

    public void setRefundDetailAmount(Money refundDetailAmount) {
        this.refundDetailAmount = refundDetailAmount;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    @Override
    public String toString() {
        return "RefundDetailInfo{" + "channelInfoList=" + channelInfoList + ", destination='" + destination + '\''
                + ", refundDetailAmount=" + refundDetailAmount + '}';
    }

}

