package com.paytm.pgplus.notificationadapter.http.application;

import com.paytm.pgplus.notificationadapter.config.ApplicationConfig;
import com.paytm.pgplus.notificationadapter.config.KafkaProducer;
import com.paytm.pgplus.notificationadapter.http.enums.ServiceUrl;
import com.paytm.pgplus.notificationadapter.http.exception.AdapterCommonUnCheckedException;
import com.paytm.pgplus.notificationadapter.http.exception.AdapterCoreClientException;
import com.paytm.pgplus.notificationadapter.http.service.IUrlService;
import com.paytm.pgplus.notificationadapter.topics.KafkaTopics;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Objects;

@Service

public class AdapterCoreClientService {

    private static final Logger log= LoggerFactory.getLogger(AdapterCoreClientService.class);

    @Autowired
    private WebClient webClient;

    @Autowired
    IUrlService urlService;

    @Autowired
    KafkaProducer kafkaProducer;

    @Autowired
    ApplicationConfig applicationConfig;

    public <S,T> void executePost(S request, ServiceUrl serviceUrl, Class<T> responseClass,final String topic) throws AdapterCoreClientException {
        try{
            String url = urlService.getUrl(serviceUrl);
            log.info("Request received in executePost with payload:{}",request);
            doPost(request, url, responseClass,topic);
        }catch (Exception e){
            log.error("Some error occurred while sending the post request", e);

        }

    }

    private <T> void verifyResponse(LinkedHashMap response,long responseTime,final String type) {
        LinkedHashMap bodyMap=null;
        LinkedHashMap responseMap=null;
        LinkedHashMap resultInfo=null;
            try {
                if (response.get("response")!=null )  {
                    responseMap=(LinkedHashMap)response.get("response");
                    if(responseMap.get("body")!=null)
                    bodyMap= (LinkedHashMap) responseMap.get("body");
                    if(bodyMap.get("resultInfo")!=null)
                    resultInfo= (LinkedHashMap) bodyMap.get("resultInfo");
                if (resultInfo !=null && resultInfo.get("resultStatus").toString().equalsIgnoreCase("S") && resultInfo.get("resultCode").toString().equalsIgnoreCase("SUCCESS")) {


                    log.info("RESPONSE_SUCCESS");
                    log.info("resultCode : {} , resultMsg : {}", resultInfo.get("resultCode"), resultInfo.get("resultMsg"));

                }else if(resultInfo !=null){
                    log.info("Response other than Success received! resultInfo:{}, resultCode : {} , resultMsg : {}",resultInfo, resultInfo.get("resultCode"), resultInfo.get("resultMsg"));
                }else {
                    log.info("resultInfo is null!");
                }
                }else{
                    log.info("Response key not received! Got response:{}",response);
                }
            }catch (Exception e){
                log.error("Failed to verify response : {} received from pg-proxy-notification, exception : {}",response.toString(),e);
            }finally {
                ThreadContext.clearAll();
            }

    }

   // @SneakyThrows
    public <S,T>  void doPost(S request, String url, Class<T> responseClass,final String topic) throws AdapterCoreClientException {
        final String type=ThreadContext.get("Type");
        try {
                    webClient.post()
                    .uri(url)
                    .accept(MediaType.APPLICATION_JSON)
                    .body(Mono.just(request), request.getClass())
                    .retrieve()
                    .onStatus(HttpStatus::isError, error -> {
                                ThreadContext.put("FLOW",type);
                                if (error.statusCode().is4xxClientError())
                                    log.error("Some exception:{} occurred at client side for payload : {}, url :{}",error,request,url );
                                else log.error("Server error returned for url {}, {}", url, error);
                                ThreadContext.clearAll();
                                return Mono.just(new AdapterCoreClientException(Objects.requireNonNull(error.toString())));

                            }
                    )
                    .bodyToMono(Object.class).take(Duration.ofMillis(applicationConfig.getWebClientTimeOut()))
                    .doOnSuccessOrError((data,flag) -> {
                        if(data==null){
                            if(topic.equals(KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY_RETRY) || topic.equals(KafkaTopics.TOPIC_PAYMENT_NOTIFY_RETRY)
                                    || topic.equals(KafkaTopics.TOPIC_REFUND_NOTIFY_RETRY) || topic.equals(KafkaTopics.TOPIC_REFUND_SUCCESS_NOTIFY_RETRY)
                                    || topic.equals(KafkaTopics.TOPIC_FUNDBACK_NOTIFY_RETRY) || topic.equals(KafkaTopics.TOPIC_WEB_FORM_CONTEXT_NOTIFY_RETRY)){
                                ThreadContext.put("FLOW",type);
                                log.error("External Service failed to process after max retries for payload : {}, error code : {}",request,HttpStatus.SERVICE_UNAVAILABLE.value());
                                ThreadContext.clearAll();
                            }else {
                                ThreadContext.put("FLOW",type);
                                log.info("Not able to get response for topic : {} ,url : {} , now pushing payload : {} to retry topic", topic,url,request);
                                ThreadContext.clearAll();
                                pushPayloadToRetryTopic(request, topic);
                            }}
                        })
                     .elapsed()
                    .subscribe(response -> {
                            if(response!=null){
                                final long responseTime=response.getT1();
                                log.info("Response received :{}, ResponseTime :{}", response.toString(),responseTime);
                                ThreadContext.put("RESPONSE_TIME",String.valueOf(responseTime));
                                ThreadContext.put("FLOW",type);
                                verifyResponse((LinkedHashMap) response.getT2(),responseTime,type);
                                ThreadContext.clearAll();

                            }else{
                                log.warn("Response received from pg-proxy-notification is null!");
                            }
                    }) ;

        }
        catch (Exception e){

            throw new AdapterCoreClientException(e.getMessage());
        }
    }

    public <S> void pushPayloadToRetryTopic(S request,final String topic) {
        String topicToPush=null;
        log.info("Payload received for retry");
        switch (topic){
            case KafkaTopics.TOPIC_PAYMENT_NOTIFY:
                topicToPush=KafkaTopics.TOPIC_PAYMENT_NOTIFY_RETRY;
                break;
            case KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY:
                topicToPush=KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY_RETRY;
                break;
            case KafkaTopics.TOPIC_REFUND_NOTIFY:
                topicToPush=KafkaTopics.TOPIC_REFUND_NOTIFY_RETRY;
                break;
            case KafkaTopics.TOPIC_REFUND_SUCCESS_NOTIFY:
                topicToPush=KafkaTopics.TOPIC_REFUND_SUCCESS_NOTIFY_RETRY;
                break;
            case KafkaTopics.TOPIC_FUNDBACK_NOTIFY:
                topicToPush=KafkaTopics.TOPIC_FUNDBACK_NOTIFY_RETRY;
                break;
            case KafkaTopics.TOPIC_WEB_FORM_CONTEXT_NOTIFY:
                topicToPush=KafkaTopics.TOPIC_WEB_FORM_CONTEXT_NOTIFY_RETRY;
                break;
            default:
                topicToPush=null;
                break;
        }
        try {
            String tempRequest=(String)request;
            if(!StringUtils.isBlank(topicToPush)){
                kafkaProducer.publishMessage(topicToPush,tempRequest);
            }else{
                log.warn("Retry topic not found for topic:{}",topic);
            }

        }
        catch (Exception e){
            log.error("Some error occurred in pushing payload :{} to kafka topic :{}",request,topicToPush);
        }
    }
}
