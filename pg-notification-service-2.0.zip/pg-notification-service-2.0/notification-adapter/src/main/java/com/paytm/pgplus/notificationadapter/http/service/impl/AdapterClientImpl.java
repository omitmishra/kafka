package com.paytm.pgplus.notificationadapter.http.service.impl;

import com.paytm.pgplus.notificationadapter.http.application.AdapterCoreClientService;
import com.paytm.pgplus.notificationadapter.http.enums.AdapterCoreUrl;
import com.paytm.pgplus.notificationadapter.http.enums.ServiceUrl;
import com.paytm.pgplus.notificationadapter.http.exception.AdapterCommonUnCheckedException;
import com.paytm.pgplus.notificationadapter.http.exception.AdapterCoreClientException;
import com.paytm.pgplus.notificationadapter.http.service.IAdapterClient;
import com.paytm.pgplus.notificationadapter.topics.KafkaTopics;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.ws.rs.core.Response;

@Service
public class AdapterClientImpl implements IAdapterClient {

    @Autowired
    AdapterCoreClientService adapterCoreClientService;

    @Override
    public void  processPaymentNotify(String payload) throws AdapterCoreClientException ,AdapterCommonUnCheckedException{
        ServiceUrl serviceUrl = AdapterCoreUrl.PAYMENT_NOTIFY;
          adapterCoreClientService.executePost(payload, serviceUrl, Response.class, KafkaTopics.TOPIC_PAYMENT_NOTIFY);
        return ;
    }

    @Override
    public void  processRetryPaymentNotify(String payload) throws AdapterCoreClientException ,AdapterCommonUnCheckedException{
        ServiceUrl serviceUrl = AdapterCoreUrl.PAYMENT_NOTIFY;
        adapterCoreClientService.executePost(payload, serviceUrl, Response.class, KafkaTopics.TOPIC_PAYMENT_NOTIFY_RETRY);
        return ;
    }

    @Override
    public void  processCloseNotify(String payload) throws AdapterCoreClientException ,AdapterCommonUnCheckedException{
        ServiceUrl serviceUrl = AdapterCoreUrl.CLOSE_NOTIFY;
        adapterCoreClientService.executePost(payload, serviceUrl, Response.class, KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY);
        return ;
    }

    @Override
    public void  processRetryCloseNotify(String payload) throws AdapterCoreClientException ,AdapterCommonUnCheckedException{
        ServiceUrl serviceUrl = AdapterCoreUrl.CLOSE_NOTIFY;
        adapterCoreClientService.executePost(payload, serviceUrl, Response.class, KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY_RETRY);
        return ;
    }

    @Override
    public void processRefundNotify(String payload) throws AdapterCoreClientException, AdapterCommonUnCheckedException{
        ServiceUrl serviceUrl = AdapterCoreUrl.REFUND_NOTIFY;
        adapterCoreClientService.executePost(payload, serviceUrl, Response.class, KafkaTopics.TOPIC_REFUND_NOTIFY);
    }

    @Override
    public void processRefundSuccessNotify(String payload) throws AdapterCoreClientException, AdapterCommonUnCheckedException{
        ServiceUrl serviceUrl = AdapterCoreUrl.REFUND_SUCCESS_NOTIFY;
        adapterCoreClientService.executePost(payload, serviceUrl, Response.class, KafkaTopics.TOPIC_REFUND_SUCCESS_NOTIFY);
    }

    @Override
    public void processRetryRefundSuccessNotify(String payload) throws AdapterCoreClientException, AdapterCommonUnCheckedException {
        ServiceUrl serviceUrl = AdapterCoreUrl.REFUND_SUCCESS_NOTIFY;
        adapterCoreClientService.executePost(payload, serviceUrl, Response.class, KafkaTopics.TOPIC_REFUND_SUCCESS_NOTIFY_RETRY);
    }

    @Override
    public void processRetryRefundNotify(String payload) throws AdapterCoreClientException, AdapterCommonUnCheckedException {
        ServiceUrl serviceUrl = AdapterCoreUrl.REFUND_NOTIFY;
        adapterCoreClientService.executePost(payload, serviceUrl, Response.class, KafkaTopics.TOPIC_REFUND_NOTIFY_RETRY);
    }

    @Override
    public void processFundbackNotify(String payload) throws AdapterCoreClientException, AdapterCommonUnCheckedException {
        ServiceUrl serviceUrl = AdapterCoreUrl.FUNDBACK_NOTIFY;
        adapterCoreClientService.executePost(payload, serviceUrl, Response.class, KafkaTopics.TOPIC_FUNDBACK_NOTIFY);
    }

    @Override
    public void processRetryFundbackNotify(String payload) throws AdapterCoreClientException, AdapterCommonUnCheckedException {
        ServiceUrl serviceUrl = AdapterCoreUrl.FUNDBACK_NOTIFY;
        adapterCoreClientService.executePost(payload, serviceUrl, Response.class, KafkaTopics.TOPIC_FUNDBACK_NOTIFY_RETRY);
    }

}
