package com.paytm.pgplus.notificationadapter.model.refundSuccessNotify;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pgplus.notificationadapter.model.Money;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class FundChannelInfo implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -5573513068842667281L;

    private PayMethodEnum payMethod;

    @Length(max = 64, message = "{lengthlimit}")
    private String cardCacheToken;

    @Length(max = 64, message = "{lengthlimit}")
    private String cardIndexNo;

    @Length(max = 64, message = "{lengthlimit}")
    private String maskedCardNo;

    @Length(max = 32, message = "{lengthlimit}")
    private String extSerialNo;

    @Length(max = 32, message = "{lengthlimit}")
    private String gateway;

    @Length(max = 64, message = "{lengthlimit}")
    private String serviceInstId;

    @Length(max = 32, message = "{lengthlimit}")
    private String assetTool;

    @Length(max = 32, message = "{lengthlimit}")
    private String sourceAssetTool;

    @NotNull(message = "{notnull}")
    private Money amount;

    @Length(max = 64, message = "{lengthlimit}")
    private String accountNo;

    @NotNull(message = "{notnull}")
    private Money chargeAmountForBuyer;

    public PayMethodEnum getPayMethod() {
        return payMethod;
    }

    public void setPayMethod(PayMethodEnum payMethod) {
        this.payMethod = payMethod;
    }

    public String getCardCacheToken() {
        return cardCacheToken;
    }

    public void setCardCacheToken(String cardCacheToken) {
        this.cardCacheToken = cardCacheToken;
    }

    public String getCardIndexNo() {
        return cardIndexNo;
    }

    public void setCardIndexNo(String cardIndexNo) {
        this.cardIndexNo = cardIndexNo;
    }

    public String getMaskedCardNo() {
        return maskedCardNo;
    }

    public void setMaskedCardNo(String maskedCardNo) {
        this.maskedCardNo = maskedCardNo;
    }

    public String getExtSerialNo() {
        return extSerialNo;
    }

    public void setExtSerialNo(String extSerialNo) {
        this.extSerialNo = extSerialNo;
    }

    public String getGateway() {
        return gateway;
    }

    public void setGateway(String gateway) {
        this.gateway = gateway;
    }

    public String getServiceInstId() {
        return serviceInstId;
    }

    public void setServiceInstId(String serviceInstId) {
        this.serviceInstId = serviceInstId;
    }

    public String getAssetTool() {
        return assetTool;
    }

    public void setAssetTool(String assetTool) {
        this.assetTool = assetTool;
    }

    public String getSourceAssetTool() {
        return sourceAssetTool;
    }

    public void setSourceAssetTool(String sourceAssetTool) {
        this.sourceAssetTool = sourceAssetTool;
    }

    public Money getAmount() {
        return amount;
    }

    public void setAmount(Money amount) {
        this.amount = amount;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public Money getChargeAmountForBuyer() {
        return chargeAmountForBuyer;
    }

    public void setChargeAmountForBuyer(Money chargeAmountForBuyer) {
        this.chargeAmountForBuyer = chargeAmountForBuyer;
    }

    @Override
    public String toString() {
        return "FundChannelInfo{" + "payMethod=" + payMethod + ", cardCacheToken='" + cardCacheToken + '\''
                + ", cardIndexNo='" + cardIndexNo + '\'' + ", maskedCardNo='" + maskedCardNo + '\'' + ", extSerialNo='"
                + extSerialNo + '\'' + ", gateway='" + gateway + '\'' + ", serviceInstId='" + serviceInstId + '\''
                + ", assetTool='" + assetTool + '\'' + ", sourceAssetTool='" + sourceAssetTool + '\'' + ", amount="
                + amount + ", accountNo='" + accountNo + '\'' + ", chargeAmountForBuyer=" + chargeAmountForBuyer + '}';
    }
}
