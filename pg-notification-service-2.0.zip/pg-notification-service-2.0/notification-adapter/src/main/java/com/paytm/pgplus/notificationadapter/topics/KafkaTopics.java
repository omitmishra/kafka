package com.paytm.pgplus.notificationadapter.topics;

public class KafkaTopics {

    private KafkaTopics() {
    }

    public static final String TOPIC_PAYMENT_NOTIFY = "TP_S_1212_EC_EVENTLOG_2001";
    public static final String TOPIC_CLOSE_ORDER_NOTIFY = "TP_S_1212_EC_EVENTLOG_2002";
    public static final String TOPIC_PAYMENT_NOTIFY_RETRY="TOPIC_PAYMENT_NOTIFY_RETRY";
    public static final String TOPIC_CLOSE_ORDER_NOTIFY_RETRY="TOPIC_CLOSE_ORDER_NOTIFY_RETRY";
    public static final String TOPIC_REFUND_NOTIFY = "TP_S_1212_EC_EVENTLOG_2004";
    public static final String TOPIC_REFUND_NOTIFY_RETRY = "TOPIC_REFUND_NOTIY_RETRY";
    public static final String TOPIC_REFUND_SUCCESS_NOTIFY = "TP_S_1212_EC_EVENTLOG_2005";
    public static final String TOPIC_REFUND_SUCCESS_NOTIFY_RETRY = "TOPIC_REFUND_SUCCESS_NOTIFY_RETRY";
    public static final String TOPIC_FUNDBACK_NOTIFY = "TP_S_1212_EC_EVENTLOG_2003";
    public static final String TOPIC_FUNDBACK_NOTIFY_RETRY = "TOPIC_FUNDBACK_NOTIFY_RETRY";

}