package com.paytm.pgplus.notificationadapter.service.impl;

import com.paytm.pgplus.notificationadapter.pool.IExecutorServicePool;
import com.paytm.pgplus.notificationadapter.service.BusinessProcessor;
import com.paytm.pgplus.notificationadapter.service.IProcessNotificationAdapterService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service(value = "retryRefundNotifyConsumerServiceImpl")
public class RetryRefundNotifyConsumerServiceImpl implements BusinessProcessor {
    private static final Logger log= LoggerFactory.getLogger(RetryRefundNotifyConsumerServiceImpl.class);

    @Autowired
    protected IExecutorServicePool executorServicePool;

    @Autowired
    @Qualifier("processRetryRefundNotifyServiceImpl")
    IProcessNotificationAdapterService processRetryRefundNotifyService;

    @Override
    public void process(String data){
        try{
            Runnable runnable = processRetryRefundNotifyService.createNotifierJob(data);
            executorServicePool.submitJob(runnable);
        }catch (Exception e){
            log.error("Exception : {} occurred while processing refundNotify retry request:{}",e.getMessage(),data);
        }
    }
}
