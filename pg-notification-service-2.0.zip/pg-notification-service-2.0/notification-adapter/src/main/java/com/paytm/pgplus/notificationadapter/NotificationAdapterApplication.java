package com.paytm.pgplus.notificationadapter;


import com.paytm.pgplus.notificationadapter.controlcenter.IApplicationCentre;
import com.paytm.pgplus.notificationadapter.controlcenter.NotificationAdapterApplicationCentreImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import javax.annotation.PostConstruct;
import java.util.Date;
import java.util.TimeZone;


@SpringBootApplication
public class NotificationAdapterApplication {

	private static final Logger LOGGER= LoggerFactory.getLogger(NotificationAdapterApplication.class);


	@Value("${component.settings.timezone}")
	private String timezone;

	@PostConstruct
	public void init(){
		TimeZone.setDefault(TimeZone.getTimeZone(timezone));
		LOGGER.info("Starting notification adapter application with Date and Timezone: "+new Date()+" ,"+timezone);
	}


	public static void main(String[] args) {
		try{
			ConfigurableApplicationContext context=SpringApplication.run(NotificationAdapterApplication.class, args);

			Runtime.getRuntime().addShutdownHook(new Thread() {
				@Override
				public void run() {
					LOGGER.warn("Stopping Notification Adaptor !!!");
					final IApplicationCentre appConfig = context.getBean(NotificationAdapterApplicationCentreImpl.class);

					if (appConfig.stopService()) {
						LOGGER.warn("Notification Adaptor stopped!");
					} else {
						LOGGER.warn("Problem in stopping Notification Adaptor !!!");
					}

				context.close();
				}
			});
			
		}catch (Throwable e){
			LOGGER.error("Some Exception Occurred while starting Application!!!", e);
		}
	}

}
