package com.paytm.pgplus.notificationadapter.model.webFormContextNotify;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CashierRequestBody implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 2507984539812733774L;

    /**
     * Transaction id created by AlipayPlus
     */
    @NotBlank(message = "{notblank}")
    @Length(max = 64, message = "{lengthlimit}")
    protected String transId;

    /**
     * Transaction id created by AlipayPlus
     */
    @NotBlank(message = "{notblank}")
    @Length(max = 128, message = "{lengthlimit}")
    protected String cashierRequestId;

    /**
     * @return the transId
     */
    public String getTransId() {
        return transId;
    }

    /**
     * @param transId
     *            the transId to set
     */
    public void setTransId(String transId) {
        this.transId = transId;
    }

    /**
     * @return the cashierRequestId
     */
    public String getCashierRequestId() {
        return cashierRequestId;
    }

    /**
     * @param cashierRequestId
     *            the cashierRequestId to set
     */
    public void setCashierRequestId(String cashierRequestId) {
        this.cashierRequestId = cashierRequestId;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("CashierRequestBody [transId=").append(transId).append(", cashierRequestId=")
                .append(cashierRequestId).append("]");
        return builder.toString();
    }

}
