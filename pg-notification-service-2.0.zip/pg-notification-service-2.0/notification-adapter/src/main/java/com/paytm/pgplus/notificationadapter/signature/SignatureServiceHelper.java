package com.paytm.pgplus.notificationadapter.signature;

import com.paytm.pgplus.notificationadapter.signature.encryption.UtilityConstants;
import org.apache.commons.codec.binary.Hex;
import org.springframework.stereotype.Service;


import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@Service
public class SignatureServiceHelper {


    private static class LazyLoader {
        public static final SignatureServiceHelper INSTANCE = new SignatureServiceHelper();
    }

    public static SignatureServiceHelper getInstance() {
        return LazyLoader.INSTANCE;
    }



    public String signApiRequest(String unsignedRequest, String key) throws UnsupportedEncodingException,
            NoSuchAlgorithmException {

        StringBuilder sb = new StringBuilder(unsignedRequest);
        sb.append(key);
        byte[] signedBytes = MessageDigest.getInstance(UtilityConstants.SHA256).digest(
                sb.toString().getBytes(UtilityConstants.CHARSET_UTF8));
        return Hex.encodeHexString(signedBytes);
        // return Base64.getEncoder().encodeToString(signedBytes);
    }


}
