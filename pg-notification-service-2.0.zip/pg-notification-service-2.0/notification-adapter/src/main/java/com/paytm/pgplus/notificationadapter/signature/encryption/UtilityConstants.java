package com.paytm.pgplus.notificationadapter.signature.encryption;

public class UtilityConstants {

    public static final String SHA256 = "SHA-256";

    /** charset UTF-8 **/
    public static final String CHARSET_UTF8 = "UTF-8";







}
