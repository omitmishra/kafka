package com.paytm.pgplus.notificationadapter.service;


public interface IProcessNotificationAdapterService {

    public Runnable createNotifierJob(String paymentNotifyRequestBody);
}
