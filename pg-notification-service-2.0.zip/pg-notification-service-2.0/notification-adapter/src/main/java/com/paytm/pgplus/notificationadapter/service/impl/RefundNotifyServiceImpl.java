package com.paytm.pgplus.notificationadapter.service.impl;

import com.paytm.pg.dto.acquiring.RefundNotifyDTO;
import com.paytm.pgplus.notificationadapter.config.ApplicationConfig;
import com.paytm.pgplus.notificationadapter.helper.AdapterThreadContextHelper;
import com.paytm.pgplus.notificationadapter.helper.DateTimeFormatter;
import com.paytm.pgplus.notificationadapter.helper.JsonMapper;
import com.paytm.pgplus.notificationadapter.helper.PayloadHelperService;
import com.paytm.pgplus.notificationadapter.http.service.impl.AdapterClientImpl;
import com.paytm.pgplus.notificationadapter.model.Money;
import com.paytm.pgplus.notificationadapter.model.AgentInfoPeon;
import com.paytm.pgplus.notificationadapter.model.refundNotify.RefundRequestBody;
import com.paytm.pgplus.notificationadapter.service.IProcessNotificationAdapterService;
import com.paytm.pgplus.notificationadapter.util.NotificationAdapterConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value = "refundNotifyServiceImpl")
public class RefundNotifyServiceImpl implements IProcessNotificationAdapterService {
    private static final Logger log = LoggerFactory.getLogger(RefundNotifyServiceImpl.class);

    @Autowired
    AdapterClientImpl adapterClientImpl;

    @Autowired
    PayloadHelperService payloadHelperService;

    @Autowired
    ApplicationConfig applicationConfig;

    @Override
    public Runnable createNotifierJob(final String kafkaPayload){
        return new Runnable() {
            @Override
            public void run() {
                if (null != kafkaPayload){
                    try{
                        ThreadContext.clearAll();
                        RefundRequestBody body = processRefundNotifyDTO(kafkaPayload);
                        AdapterThreadContextHelper.setThreadContext(body.getAcquirementId(), body.getMerchantTransId(), "RefundNotify");
                        if(applicationConfig.isCheckForShadowMerchant() && body.getMerchantId().matches(".*[A-Za-z].*") && body.getMerchantId().matches(".*[0-9].*") && body.getMerchantId().matches("[A-Za-z0-9]*"))
                        {
                            log.info("Shadow Request received for mid:{}",body.getMerchantId());
                        }else {
                            adapterClientImpl.processRefundNotify(payloadHelperService.getRefundNotifyPayload(body));
                        }
                    } catch (Exception e){
                        log.error("Some Exception {} occurred during mapping of refundNotifyDTO to RefundRequestBody for payload: {}", e,kafkaPayload);
                    }
                } else {
                    log.error("Payload can't be null for refundNotify!!");
                }
            }
        };
    }

    private RefundRequestBody processRefundNotifyDTO(String kafkaPayload) throws Exception{
        RefundRequestBody refundRequestBody = new RefundRequestBody();
        try {
            RefundNotifyDTO refundNotifyDTO = JsonMapper.mapJsonToObject(kafkaPayload, RefundNotifyDTO.class);

            refundRequestBody.setAcquirementId(refundNotifyDTO.getAcquirementId());
            refundRequestBody.setMerchantTransId(refundNotifyDTO.getMerchantTransId());
            refundRequestBody.setRefundId(refundNotifyDTO.getRefundId());

            Money orderAmount = new Money();
            if (refundNotifyDTO.getOrderAmount() != null){
                orderAmount.setValue(String.valueOf(refundNotifyDTO.getOrderAmount().getCent()));
                if (refundNotifyDTO.getOrderAmount().getCurrency() != null)
                    orderAmount.setCurrency(refundNotifyDTO.getOrderAmount().getCurrency().getCurrencyCode());
            }
            refundRequestBody.setOrderAmount(orderAmount);

            Money refundAmount = new Money();
            if (refundNotifyDTO.getRefundAmount() != null){
                refundAmount.setValue(String.valueOf(refundNotifyDTO.getRefundAmount().getCent()));
                if (refundNotifyDTO.getRefundAmount().getCurrency() != null)
                    refundAmount.setCurrency(refundNotifyDTO.getRefundAmount().getCurrency().getCurrencyCode());
            }
            refundRequestBody.setRefundAmount(refundAmount);

            refundRequestBody.setCreateOrderTime(DateTimeFormatter.getISO861DateTimeStringWithoutMillis(refundNotifyDTO.getCreateOrderTime()));
            refundRequestBody.setRefundApplyTime(DateTimeFormatter.getISO861DateTimeStringWithoutMillis(refundNotifyDTO.getRefundApplyTime()));
            refundRequestBody.setRefundPrepareSuccessTime(DateTimeFormatter.getISO861DateTimeStringWithoutMillis(refundNotifyDTO.getRefundPrepareSuccessTime()));
            refundRequestBody.setRefundResult(refundNotifyDTO.getRefundResult());
            String extendInfo = JsonMapper.mapObjectToJson(refundNotifyDTO.getExtendInfo());
            refundRequestBody.setExtendInfo(extendInfo);
            String orderExtendInfo = JsonMapper.mapObjectToJson(refundNotifyDTO.getOrderExtendInfo());
            refundRequestBody.setOrderExtendInfo(orderExtendInfo);
            refundRequestBody.setRefundReason(refundNotifyDTO.getRefundReason());

            AgentInfoPeon agentInfoPeon = new AgentInfoPeon();
            if (refundNotifyDTO.getAgentInfo() != null){
                agentInfoPeon.setEmail(refundNotifyDTO.getAgentInfo().getEmail());
                agentInfoPeon.setEmployeeId(refundNotifyDTO.getAgentInfo().getEmployeeId());
                agentInfoPeon.setName(refundNotifyDTO.getAgentInfo().getName());
                agentInfoPeon.setPhoneNo(refundNotifyDTO.getAgentInfo().getPhoneNo());
            }
            refundRequestBody.setAgentInfo(agentInfoPeon);
            refundRequestBody.setProductCode(refundNotifyDTO.getProductCode());
            if(null == refundNotifyDTO.getAdditionalMetaInfo()){
                throw new Exception("Additional Meta info not Found!");
            }
            String merchantId=refundNotifyDTO.getAdditionalMetaInfo().get(NotificationAdapterConstants.ALIPAY_MID);
            if(StringUtils.isBlank(merchantId)){
                throw new Exception("Merchant Id can't be blank!");
            }
            refundRequestBody.setMerchantId(merchantId);

        } catch (Exception e){

            throw e;
        }
        return refundRequestBody;
    }

}
