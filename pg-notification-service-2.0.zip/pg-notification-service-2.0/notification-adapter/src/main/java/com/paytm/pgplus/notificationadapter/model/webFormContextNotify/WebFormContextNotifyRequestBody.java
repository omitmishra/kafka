/**
 * 
 */
package com.paytm.pgplus.notificationadapter.model.webFormContextNotify;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

@JsonIgnoreProperties(ignoreUnknown = true)
public class WebFormContextNotifyRequestBody extends CashierRequestBody {

    /**
     *
     */
    private static final long serialVersionUID = 256556849995094915L;

    /**
     * Transaction id created by AlipayPlus
     */
    @Length(max = 12288, message = "{lengthlimit}")
    private String webFormContext;

    private String webFormId;

    /**
     * @return the webFormContext
     */
    public String getWebFormContext() {
        return webFormContext;
    }

    /**
     * @param webFormContext
     *            the webFormContext to set
     */
    public void setWebFormContext(String webFormContext) {
        this.webFormContext = webFormContext;
    }

    public String getWebFormId() {
        return webFormId;
    }

    public void setWebFormId(String webFormId) {
        this.webFormId = webFormId;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("WebFormContextNotifyRequestBody [transId=").append(transId).append(", cashierRequestId=")
                .append(cashierRequestId).append(", webFormId=").append(webFormId).append("]");
        return builder.toString();
    }

}