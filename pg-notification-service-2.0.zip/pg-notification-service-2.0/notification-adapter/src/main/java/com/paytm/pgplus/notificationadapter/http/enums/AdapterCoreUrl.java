package com.paytm.pgplus.notificationadapter.http.enums;

public enum AdapterCoreUrl implements ServiceUrl{
    PAYMENT_NOTIFY("/pgproxy-notification/alipayplus/acquiring/order/paymentNotify"),
    CLOSE_NOTIFY("/pgproxy-notification/alipayplus/acquiring/order/closeNotify"),
    REFUND_NOTIFY("/pgproxy-notification/alipayplus/acquiring/refund/refundNotify"),
    REFUND_SUCCESS_NOTIFY("/pgproxy-notification/alipayplus/acquiring/refund/refundSuccessNotify"),
    FUNDBACK_NOTIFY("/pgproxy-notification/alipayplus/acquiring/order/fundBackNotify"),
    WEB_FORM_CONTEXT_NOTIFY("/pgproxy-notification/alipayplus/payment/cashier/webFormContextNotify");

    private String functionalUrl;

    AdapterCoreUrl(final String functionalUrl) {
        this.functionalUrl = functionalUrl;
    }

    @Override
    public String getFunctionalUrl() {
        return this.functionalUrl;
    }
}
