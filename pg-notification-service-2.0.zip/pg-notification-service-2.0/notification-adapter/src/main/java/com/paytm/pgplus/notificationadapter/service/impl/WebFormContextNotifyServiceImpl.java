package com.paytm.pgplus.notificationadapter.service.impl;

import com.paytm.pg.dto.payments.WebFormNotifyDTO;
import com.paytm.pgplus.notificationadapter.helper.AdapterThreadContextHelper;
import com.paytm.pgplus.notificationadapter.helper.JsonMapper;
import com.paytm.pgplus.notificationadapter.helper.PayloadHelperService;
import com.paytm.pgplus.notificationadapter.http.service.impl.AdapterClientImpl;
import com.paytm.pgplus.notificationadapter.model.webFormContextNotify.WebFormContextNotifyRequestBody;
import com.paytm.pgplus.notificationadapter.service.IProcessNotificationAdapterService;
import org.apache.logging.log4j.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value = "webFormContextNotifyServiceImpl")
public class WebFormContextNotifyServiceImpl implements IProcessNotificationAdapterService {

    private static final Logger log = LoggerFactory.getLogger(WebFormContextNotifyServiceImpl.class);

    @Autowired
    AdapterClientImpl adapterClientImpl;

    @Autowired
    PayloadHelperService payloadHelperService;

    @Override
    public Runnable createNotifierJob(String kafkaPayload){
        return new Runnable() {
            @Override
            public void run() {
                if (null != kafkaPayload) {
                    try {
                        ThreadContext.clearAll();
                        WebFormContextNotifyRequestBody body = processWebFormNotifyDTO(kafkaPayload);
                        AdapterThreadContextHelper.setThreadContext(body.getTransId(), null,"WebFormContextNotify");
                        adapterClientImpl.processWebFormContextNotify(payloadHelperService.getWebFormContextNotifyPayload(body));

                    } catch (final Exception ex) {
                        log.error("Some Exception {} occurred during mapping of webFormNotifyDTO to webFormContextNotifyRequestBody for payload: {}", ex,kafkaPayload);
                    }
                } else {
                    log.error("Payload can't be null for webFormContextNotify!!");
                }
            }
        };
    }

    private WebFormContextNotifyRequestBody processWebFormNotifyDTO(String payload) throws Exception{
        WebFormContextNotifyRequestBody webFormContextNotifyRequestBody=new WebFormContextNotifyRequestBody();
        try{
            WebFormNotifyDTO webFormNotifyDTO= JsonMapper.mapJsonToObject(payload,WebFormNotifyDTO.class);
            webFormContextNotifyRequestBody.setCashierRequestId(webFormNotifyDTO.getPaymentBizRequestId());
            webFormContextNotifyRequestBody.setTransId(webFormNotifyDTO.getTransId());
            webFormContextNotifyRequestBody.setWebFormId(webFormNotifyDTO.getWebFormId());
        }catch (Exception e){
            throw e;
        }

        return webFormContextNotifyRequestBody;
    }
}
