package com.paytm.pgplus.notificationadapter.controlcenter;

import com.paytm.pgplus.notificationadapter.pool.IExecutorServicePool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

@Service(value = "notificationAdapterApplicationCentreImpl")
public class NotificationAdapterApplicationCentreImpl implements IApplicationCentre {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationAdapterApplicationCentreImpl.class);

    private static final AtomicBoolean stopped = new AtomicBoolean(false);

    private final AtomicInteger poolCounter = new AtomicInteger(1);

    @Autowired
    @Qualifier("notificationAdapterExecutorServicePoolImpl")
    private IExecutorServicePool executorServicePool;

    @Override
    public boolean stopService() {
        stopped.set(true);
        try {
            executorServicePool.shutDown();
        } catch (final Exception ex) {
            LOGGER.error("Error in stopping Notification-Queue-Handler !: ", ex);
            return false;
        }
        return stopped.get();
    }

    @Override
    public boolean isStopped() {
        return stopped.get();
    }

    @Override
    public final int getRequestCount() {
        return poolCounter.get();
    }

    @Override
    public final int incrementRequestCountAndGet() {
        return poolCounter.incrementAndGet();
    }

    @Override
    public final int decrementRequestCountAndGet() {
        return poolCounter.decrementAndGet();


    }

}

