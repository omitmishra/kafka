package com.paytm.pgplus.notificationadapter.model.refundSuccessNotify;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.paytm.pg.common.structures.ResultInfo;
import com.paytm.pgplus.notificationadapter.model.AcquirementRequestBody;
import com.paytm.pgplus.notificationadapter.model.AgentInfoPeon;
import com.paytm.pgplus.notificationadapter.model.InputUserInfo;
import com.paytm.pgplus.notificationadapter.model.Money;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RefundSuccessRequestBody extends AcquirementRequestBody {

    /**
     * Serial version UID
     */
    private static final long serialVersionUID = 5404695856728945364L;

    @NotNull(message = "{notnull}")
    private Money orderAmount;

    @NotBlank(message = "{notblank}")
    @Length(max = 32, message = "{lengthlimit}")
    private String merchantId;

    private String createdTime;

    @NotBlank(message = "{notblank}")
    @Length(max = 64, message = "{lengthlimit}")
    private String contractId;

    @NotBlank(message = "{notblank}")
    @Length(max = 64, message = "{lengthlimit}")
    private String productCode;

    @NotBlank(message = "{notblank}")
    private String createOrderTime;

    private InputUserInfo buyerInfo;

    @NotBlank(message = "{notblank}")
    @Length(max = 64, message = "{lengthlimit}")
    private String merchantRequestId;

    @NotBlank(message = "{notblank}")
    @Length(max = 64, message = "{lengthlimit}")
    private String refundId;

    @NotNull(message = "{notnull}")
    private Money refundAmount;

    @NotBlank(message = "{notblank}")
    private String refundApplyTime;

    @JsonProperty("isOffset")
    private boolean offset;

    @NotBlank(message = "{notblank}")
    private String refundSuccessTime;

    // Merchant requested destination
    private String destination;

    @NotNull(message = "{notnull}")
    private List<FundChannelInfo> refundFundChannelInfo;

    private Money totalSuccessfulRefundedAmountOnOrder;

    @Length(max = 1024, message = "{lengthlimit}")
    private String refundReason;

    /**
     * refund detail information
     */
    private List<RefundDetailInfo> refundDetailInfoList;

    private boolean returnChargeToPayer;

    private String extendInfo;

    private String orderExtendInfo;

    @NotNull(message = "{notnull}")
    @Valid
    private ResultInfo refundSuccessResult;

    private String rrnCode;

    private String pwpCategory;

    private AgentInfoPeon agentInfo;

    public RequestRefundChannelInfo getRequestRefundChannelInfo() {
        return requestRefundChannelInfo;
    }

    public void setRequestRefundChannelInfo(RequestRefundChannelInfo requestRefundChannelInfo) {
        this.requestRefundChannelInfo = requestRefundChannelInfo;
    }

    private RequestRefundChannelInfo requestRefundChannelInfo;

    public List<RefundDetailInfo> getRefundDetailInfoList() {
        return refundDetailInfoList;
    }

    public void setRefundDetailInfoList(List<RefundDetailInfo> refundDetailInfoList) {
        this.refundDetailInfoList = refundDetailInfoList;
    }

    public Money getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(Money orderAmount) {
        this.orderAmount = orderAmount;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getCreateOrderTime() {
        return createOrderTime;
    }

    public void setCreateOrderTime(String createOrderTime) {
        this.createOrderTime = createOrderTime;
    }

    public InputUserInfo getBuyerInfo() {
        return buyerInfo;
    }

    public void setBuyerInfo(InputUserInfo buyerInfo) {
        this.buyerInfo = buyerInfo;
    }

    public String getMerchantRequestId() {
        return merchantRequestId;
    }

    public void setMerchantRequestId(String merchantRequestId) {
        this.merchantRequestId = merchantRequestId;
    }

    public String getRefundId() {
        return refundId;
    }

    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }

    public Money getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(Money refundAmount) {
        this.refundAmount = refundAmount;
    }

    public String getRefundApplyTime() {
        return refundApplyTime;
    }

    public void setRefundApplyTime(String refundApplyTime) {
        this.refundApplyTime = refundApplyTime;
    }

    public boolean isOffset() {
        return offset;
    }

    public void setOffset(boolean offset) {
        offset = offset;
    }

    public String getRefundSuccessTime() {
        return refundSuccessTime;
    }

    public void setRefundSuccessTime(String refundSuccessTime) {
        this.refundSuccessTime = refundSuccessTime;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public List<FundChannelInfo> getRefundFundChannelInfo() {
        return refundFundChannelInfo;
    }

    public void setRefundFundChannelInfo(List<FundChannelInfo> refundFundChannelInfo) {
        this.refundFundChannelInfo = refundFundChannelInfo;
    }

    public Money getTotalSuccessfulRefundedAmountOnOrder() {
        return totalSuccessfulRefundedAmountOnOrder;
    }

    public void setTotalSuccessfulRefundedAmountOnOrder(Money totalSuccessfulRefundedAmountOnOrder) {
        this.totalSuccessfulRefundedAmountOnOrder = totalSuccessfulRefundedAmountOnOrder;
    }

    public String getRefundReason() {
        return refundReason;
    }

    public void setRefundReason(String refundReason) {
        this.refundReason = refundReason;
    }

    public boolean isReturnChargeToPayer() {
        return returnChargeToPayer;
    }

    public void setReturnChargeToPayer(boolean returnChargeToPayer) {
        this.returnChargeToPayer = returnChargeToPayer;
    }

    public ResultInfo getRefundSuccessResult() {
        return refundSuccessResult;
    }

    public void setRefundSuccessResult(ResultInfo refundSuccessResult) {
        this.refundSuccessResult = refundSuccessResult;
    }

    public String getRrnCode() {
        return rrnCode;
    }

    public void setRrnCode(String rrnCode) {
        this.rrnCode = rrnCode;
    }

    public void setExtendInfo(String extendInfo) {
        this.extendInfo = extendInfo;
    }

    public void setOrderExtendInfo(String orderExtendInfo) {
        this.orderExtendInfo = orderExtendInfo;
    }

    public String getExtendInfo() {
        return extendInfo;
    }

    public String getOrderExtendInfo() {
        return orderExtendInfo;
    }

    public String getPwpCategory() {
        return pwpCategory;
    }

    public void setPwpCategory(String pwpCategory) {
        this.pwpCategory = pwpCategory;
    }

    public AgentInfoPeon getAgentInfo() {
        return agentInfo;
    }

    public void setAgentInfo(AgentInfoPeon agentInfo) {
        this.agentInfo = agentInfo;
    }
}
