package com.paytm.pgplus.notificationadapter.service.impl;

import com.paytm.pgplus.notificationadapter.pool.IExecutorServicePool;
import com.paytm.pgplus.notificationadapter.service.BusinessProcessor;
import com.paytm.pgplus.notificationadapter.service.IProcessNotificationAdapterService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service(value = "webFormContextNotifyConsumerServiceImpl")
public class WebFormContextNotifyConsumerServiceImpl implements BusinessProcessor {

    private static final Logger LOGGER = LoggerFactory.getLogger(WebFormContextNotifyConsumerServiceImpl.class.getName());

    @Autowired
    protected IExecutorServicePool executorServicePool;


    @Autowired
    @Qualifier("webFormContextNotifyServiceImpl")
    private IProcessNotificationAdapterService webFormContextNotifyService;


    @Override
    public void process(final String data) {
        try{
            final Runnable notifierJob = webFormContextNotifyService.createNotifierJob(data);

            executorServicePool.submitJob(notifierJob);
        }catch (final  Exception ex){
            LOGGER.error("Exception occured :{} not able to submit job for  webFormContextNotifyService:{}",ex,data);

        }


    }
}
