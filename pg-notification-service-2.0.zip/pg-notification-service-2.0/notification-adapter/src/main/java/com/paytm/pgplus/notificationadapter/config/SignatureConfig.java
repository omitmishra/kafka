package com.paytm.pgplus.notificationadapter.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SignatureConfig {

    @Value("${sha256.key}")
    private String shaKey;

    public String getShaKey() {
        return shaKey;
    }
}
