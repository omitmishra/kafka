package com.paytm.pgplus.notificationadapter.service.impl;

import com.paytm.pgplus.notificationadapter.pool.IExecutorServicePool;
import com.paytm.pgplus.notificationadapter.service.BusinessProcessor;
import com.paytm.pgplus.notificationadapter.service.IProcessNotificationAdapterService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service(value = "retryRefundSuccessNotifyConsumerServiceImpl")
public class RetryRefundSuccessNotifyConsumerServiceImpl implements BusinessProcessor {
    private static final Logger log= LoggerFactory.getLogger(RetryRefundSuccessNotifyConsumerServiceImpl.class);

    @Autowired
    protected IExecutorServicePool executorServicePool;

    @Autowired
    @Qualifier("processRetryRefundSuccessNotifyServiceImpl")
    IProcessNotificationAdapterService processRetryRefundSuccessNotifyService;

    @Override
    public void process(String data){
        try{
            Runnable runnable = processRetryRefundSuccessNotifyService.createNotifierJob(data);
            executorServicePool.submitJob(runnable);
        }catch (Exception e){
            log.error("Exception : {} occurred while processing refundSuccessNotify retry request:{}",e.getMessage(),data);
        }
    }
}
