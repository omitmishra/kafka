package com.paytm.pgplus.notificationadapter.kafka;


import com.paytm.pgplus.notificationadapter.service.BusinessProcessor;
import com.paytm.pgplus.notificationadapter.topics.KafkaTopics;
import com.paytm.pgplus.notificationadapter.util.KafkaConsumerUtil;
import com.paytm.pgplus.notificationadapter.util.NotificationAdapterConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class NotificationAdapterListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationAdapterListener.class);

    @Autowired
    private KafkaConsumerUtil kafkaConsumerUtil;

    @Autowired
    @Qualifier("paymentNotifyConsumerServiceImpl")
    private BusinessProcessor paymentNotifyConsumerService;

    @Autowired
    @Qualifier("closeNotifyConsumerServiceImpl")
    private BusinessProcessor closeNotifyConsumerService;

    @Autowired
    @Qualifier("retryPaymentNotifyConsumerServiceImpl")
    private BusinessProcessor retryPaymentNotifyConsumerServiceImpl;

    @Autowired
    @Qualifier("retryCloseNotifyConsumerServiceImpl")
    private BusinessProcessor retryCloseNotifyConsumerServiceImpl;

    @Autowired
    @Qualifier("refundNotifyConsumerServiceImpl")
    private BusinessProcessor refundNotifyConsumerServiceImpl;

    @Autowired
    @Qualifier("refundSuccessNotifyConsumerServiceImpl")
    private BusinessProcessor refundSuccessNotifyConsumerServiceImpl;

    @Autowired
    @Qualifier("retryRefundSuccessNotifyConsumerServiceImpl")
    private BusinessProcessor retryRefundSuccessNotifyConsumerServiceImpl;

    @Autowired
    @Qualifier("retryRefundNotifyConsumerServiceImpl")
    private BusinessProcessor retryRefundNotifyConsumerServiceImpl;

    @Autowired
    @Qualifier("fundbackNotifyConsumerServiceImpl")
    private BusinessProcessor fundbackNotifyConsumerServiceImpl;

    @Autowired
    @Qualifier("retryFundbackNotifyConsumerServiceImpl")
    private BusinessProcessor retryFundbackNotifyConsumerServiceImpl;

    @Autowired
    @Qualifier("webFormContextNotifyConsumerServiceImpl")
    private BusinessProcessor webFormContextNotifyConsumerServiceImpl;

    @Autowired
    @Qualifier("retryWebFormContextNotifyConsumerServiceImpl")
    private BusinessProcessor retryWebFormContextNotifyConsumerServiceImpl;

    @Autowired
    @Qualifier("kafkaProducerTemplate")
    private KafkaTemplate<String, String> template;

    @KafkaListener(topics = KafkaTopics.TOPIC_PAYMENT_NOTIFY,groupId = NotificationAdapterConstants.KAFKA_GROUP_PAYMENT_NOTIFY)
    void paymentNotify(String payload) {
        LOGGER.info("Payload received for paymentNotify: {}", payload);
        kafkaConsumerUtil.preConsume();
        paymentNotifyConsumerService.process(payload);
    }


    @KafkaListener(topics = KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY, groupId = NotificationAdapterConstants.KAFKA_GROUP_CLOSE_NOTIFY)
    void closeNotify(String payload) {
        LOGGER.info("Payload received for closeNotify: {}", payload);
        kafkaConsumerUtil.preConsume();
        closeNotifyConsumerService.process(payload);
    }

    @KafkaListener(topics = KafkaTopics.TOPIC_PAYMENT_NOTIFY_RETRY ,groupId = NotificationAdapterConstants.KAFKA_GROUP_PAYMENT_NOTIFY_RETRY)
    void paymentNotifyRetry(String payload) {
        LOGGER.info("Payload received for paymentNotifyRetry: {}", payload);
        kafkaConsumerUtil.preConsume();
        retryPaymentNotifyConsumerServiceImpl.process(payload);
    }

    @KafkaListener(topics = KafkaTopics.TOPIC_CLOSE_ORDER_NOTIFY_RETRY,groupId = NotificationAdapterConstants.KAFKA_GROUP_CLOSE_NOTIFY_RETRY)
    void closeNotifyRetry(String payload) {
        LOGGER.info("Payload received for closeNotifyRetry: {}", payload);
        kafkaConsumerUtil.preConsume();
        retryCloseNotifyConsumerServiceImpl.process(payload);
    }

    @KafkaListener(topics = KafkaTopics.TOPIC_REFUND_NOTIFY, groupId = NotificationAdapterConstants.KAFKA_GROUP_REFUND_NOTIFY)
    void refundNotify(String payload){
        LOGGER.info("Payload received for refundNotify: {}", payload);
        kafkaConsumerUtil.preConsume();
        refundNotifyConsumerServiceImpl.process(payload);
    }

    @KafkaListener(topics = KafkaTopics.TOPIC_REFUND_SUCCESS_NOTIFY,groupId = NotificationAdapterConstants.KAFKA_GROUP_REFUND_SUCCESS_NOTIFY)
    void refundSuccessNotify(String payload){
        LOGGER.info("Payload received for refundSuccessNotify: {}", payload);
        kafkaConsumerUtil.preConsume();
        refundSuccessNotifyConsumerServiceImpl.process(payload);
    }

    @KafkaListener(topics = KafkaTopics.TOPIC_REFUND_NOTIFY_RETRY, groupId = NotificationAdapterConstants.KAFKA_GROUP_REFUND_NOTIFY_RETRY)
    void refundNotifyRetry(String payload){
        LOGGER.info("Payload received for refundNotify retry: {}", payload);
        kafkaConsumerUtil.preConsume();
        retryRefundNotifyConsumerServiceImpl.process(payload);
    }

    @KafkaListener(topics = KafkaTopics.TOPIC_REFUND_SUCCESS_NOTIFY_RETRY, groupId = NotificationAdapterConstants.KAFKA_GROUP_REFUND_SUCCESS_NOTIFY_RETRY)
    void refundSuccessNotifyRetry(String payload){
        LOGGER.info("Payload received for refundSuccessNotify retry: {}", payload);
        kafkaConsumerUtil.preConsume();
        retryRefundSuccessNotifyConsumerServiceImpl.process(payload);
    }

    @KafkaListener(topics = KafkaTopics.TOPIC_FUNDBACK_NOTIFY, groupId = NotificationAdapterConstants.KAFKA_GROUP_FUNDBACK_NOTIFY)
    void fundbackNotify(String payload){
        LOGGER.info("Payload received for fundbackNotify : {}", payload);
        kafkaConsumerUtil.preConsume();
        fundbackNotifyConsumerServiceImpl.process(payload);
    }

    @KafkaListener(topics = KafkaTopics.TOPIC_FUNDBACK_NOTIFY_RETRY, groupId = NotificationAdapterConstants.KAFKA_GROUP_FUNDBACK_NOTIFY_RETRY)
    void fundbackNotifyRetry(String payload){
        LOGGER.info("Payload received for fundbackNotify retry : {}", payload);
        kafkaConsumerUtil.preConsume();
        retryFundbackNotifyConsumerServiceImpl.process(payload);
    }

    @KafkaListener(topics = KafkaTopics.TOPIC_WEB_FORM_CONTEXT_NOTIFY, groupId = NotificationAdapterConstants.KAFKA_GROUP_WEB_FORM_CONTEXT_NOTIFY)
    void webFormContextNotify(String payload){
        LOGGER.info("Payload received for webFormContextNotify : {}", payload);
        kafkaConsumerUtil.preConsume();
        webFormContextNotifyConsumerServiceImpl.process(payload);
    }

    @KafkaListener(topics = KafkaTopics.TOPIC_WEB_FORM_CONTEXT_NOTIFY_RETRY, groupId = NotificationAdapterConstants.KAFKA_GROUP_WEB_FORM_CONTEXT_NOTIFY_RETRY)
    void webFormContextNotifyRetry(String payload){
        LOGGER.info("Payload received for webFormContextNotify retry : {}", payload);
        kafkaConsumerUtil.preConsume();
        retryWebFormContextNotifyConsumerServiceImpl.process(payload);
    }
}
