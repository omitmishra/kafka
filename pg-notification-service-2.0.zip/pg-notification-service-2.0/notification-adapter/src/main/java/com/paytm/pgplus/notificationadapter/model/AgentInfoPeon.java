package com.paytm.pgplus.notificationadapter.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentInfoPeon implements Serializable {

    private static final long serialVersionUID = 1L;

    private String employeeId;
    private String name;
    private String phoneNo;
    private String email;

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        StringBuilder buf = new StringBuilder();
        buf.append(" { ");
        buf.append("RefundAgentInfoPeon{").append('\'');
        buf.append("employeeId='" + employeeId).append('\'');
        buf.append(", name='" + name).append('\'');
        buf.append(", phoneNo='" + phoneNo).append('\'');
        buf.append(", email='" + email).append('\'');
        buf.append('}');
        return buf.toString();
    }
}

