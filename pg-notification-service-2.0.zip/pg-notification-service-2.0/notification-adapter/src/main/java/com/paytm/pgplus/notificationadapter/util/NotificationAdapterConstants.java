package com.paytm.pgplus.notificationadapter.util;


public class NotificationAdapterConstants {


    //kafka group
    public static final String KAFKA_GROUP_PAYMENT_NOTIFY = "pgp-payment-notify";
    public static final String KAFKA_GROUP_CLOSE_NOTIFY = "pgp-close-notify";
    public static final String KAFKA_GROUP_PAYMENT_NOTIFY_RETRY = "pgp-payment-notify-retry";
    public static final String KAFKA_GROUP_CLOSE_NOTIFY_RETRY = "pgp-close-notify-retry";
    public static final String KAFKA_GROUP_REFUND_NOTIFY= "pgp-refund-notify";
    public static final String KAFKA_GROUP_REFUND_NOTIFY_RETRY = "pgp-refund-notify-retry";
    public static final String KAFKA_GROUP_REFUND_SUCCESS_NOTIFY= "pgp-refund-success-notify";
    public static final String KAFKA_GROUP_REFUND_SUCCESS_NOTIFY_RETRY = "pgp-refund-success-notify-retry";
    public static final String KAFKA_GROUP_FUNDBACK_NOTIFY = "pgp-fundbank-notify";
    public static final String KAFKA_GROUP_FUNDBACK_NOTIFY_RETRY = "pgp-fundback-notify-retry";
    public static final String KAFKA_GROUP_WEB_FORM_CONTEXT_NOTIFY = "pgp-web-form-context-notify";
    public static final String KAFKA_GROUP_WEB_FORM_CONTEXT_NOTIFY_RETRY = "pgp-web-form-context-notify-retry";

    //Alipay Mid constant
    public static final String ALIPAY_MID="pplusMid";

    public static class Configurations {

        public static final String SIGN_PROPERTY_FILE_LOCATION = "config.properties";
//        public static final String MIN_POOL_SIZE = "min.pool.size";
//        public static final String MAX_POOL_SIZE = "max.pool.size";
//        public static final String KEEP_ALIVE_TIME_SECONDS = "keep.alive.time";
//        public static final  String  SHUTDOWN_WAIT_TIME_SECONDS= "shutdown.wait.time";
//
//
//        public static final  int DEFAULT_MIN_POOL_SIZE= 0;
//
//        public static final  int DEFAULT_MAX_POOL_SIZE= 0;
//
//        public static final  int DEFAULT_KEEP_ALIVE_TIME_SECONDS= 0;
//
//        public static final  int DEFAULT_SHUT_DOWN_TIME_SECONDS= 0;

    }

}
