package com.paytm.pgplus.notificationadapter.service.impl;

import com.paytm.pgplus.notificationadapter.helper.AdapterThreadContextHelper;
import com.paytm.pgplus.notificationadapter.http.service.impl.AdapterClientImpl;
import com.paytm.pgplus.notificationadapter.service.IProcessNotificationAdapterService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value = "processRetryWebFormContextNotifyServiceImpl")
public class ProcessRetryWebFormContextNotifyServiceImpl implements IProcessNotificationAdapterService {

    private static final Logger log= LoggerFactory.getLogger(ProcessRetryWebFormContextNotifyServiceImpl.class);

    @Autowired
    AdapterClientImpl adapterClient;

    @Override
    public Runnable createNotifierJob(String webFormContextNotifybody){
        return new Runnable() {
            @Override
            public void run() {
                try{
                    AdapterThreadContextHelper.setThreadContextForWebContextRetry(webFormContextNotifybody);
                    adapterClient.processRetryWebFormContextNotify(webFormContextNotifybody);
                } catch (Exception e){
                    log.error("Exception : {} occurred while processing webFormContextNotify retry request:{}",e.getMessage(),webFormContextNotifybody);
                }
            }
        };
    }
}
