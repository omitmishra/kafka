package com.paytm.pgplus.notificationadapter.model.paymentNotify;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.paytm.pgplus.notificationadapter.helper.JsonMapper;
import com.paytm.pgplus.notificationadapter.model.Money;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.Length;

import javax.validation.Valid;
import java.io.Serializable;
import java.util.Collections;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RefundChannelInfo implements Serializable {

    /** serialVersionUID */
    private static final long serialVersionUID = 1L;

    /**
     * rrnCode from bank side
     */
    @Length(max = 64, message = "exceed rrnCode maximum length 64")
    private String rrnCode;

    /**
     * addAndPay flag received from P+
     */
    private Boolean addAndPay;

    /**
     * refunded amount through current channel
     */
    @Valid
    private Money amount;

    /**
     * The pay method name
     */
    @Length(max = 64, message = "exceed payMethod maximum length 64")
    private String payMethod;

    /** masked card number */
    @Length(max = 32, message = "exceed maskedCardNo maximum length 32")
    private String maskedCardNumber;

    /**
     * virtual payment address
     */
    @Length(max = 64, message = "exceed virtualPaymentAddress maximum length 64")
    private String virtualPaymentAddress;

    /** masked bank account number */
    @Length(max = 64, message = "exceed maskedBankAccountNumber maximum length 64")
    private String maskedBankAccountNumber;

    /**
     * issuing bank's full name
     */
    @Length(max = 32, message = "exceed issuingBankName maximum length 32")
    private String issuingBankName;

    /**
     * card scheme, refer to CardSchemaEnum
     */
    @Length(max = 32, message = "exceed cardScheme maximum length 32")
    private String cardScheme;
    /**
     * buyer user's mobile number
     *
     */
    @Length(max = 128, message = "the max length 128")
    private String userMobileNo;

    private String txnAmount = "";

    private String status;

    private RecoverChannelInfo recoverChannelInfo;

    public RecoverChannelInfo getRecoverChannelInfo() {
        return recoverChannelInfo;
    }

    public void setRecoverChannelInfo(RecoverChannelInfo recoverChannelInfo) {
        this.recoverChannelInfo = recoverChannelInfo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    private String ifscCode;

    private String prepaidCard;

    private String refundTurnAroundTime;

    private String bankCode;

    private String extendInfo;

    /**
     * issuing bank's code
     */
    @Length(max = 32, message = "exceed issuingBankCode maximum length 32")
    private String issuingBankCode;

    public String getIssuingBankCode() {
        return issuingBankCode;
    }

    public void setIssuingBankCode(String issuingBankCode) {
        this.issuingBankCode = issuingBankCode;
    }

//    public Map<String, String> getExtendInfoMap() {
//        try {
//            if (StringUtils.isNotBlank(extendInfo)) {
//                return JsonMapper.mapJsonToObject(extendInfo, Map.class);
//            }
//        } catch (final JsonProcessingException e) {
//        }
//        return Collections.emptyMap();
//    }

    public void setExtendInfo(String extendInfo) {
        this.extendInfo = extendInfo;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

    public void setRrnCode(String rrnCode) {
        this.rrnCode = rrnCode;
    }

    public void setAmount(Money amount) {
        this.amount = amount;
    }

    public void setPayMethod(String payMethod) {
        this.payMethod = payMethod;
    }

    public void setMaskedCardNumber(String maskedCardNumber) {
        this.maskedCardNumber = maskedCardNumber;
    }

    public void setVirtualPaymentAddress(String virtualPaymentAddress) {
        this.virtualPaymentAddress = virtualPaymentAddress;
    }

    public void setMaskedBankAccountNumber(String maskedBankAccountNumber) {
        this.maskedBankAccountNumber = maskedBankAccountNumber;
    }

    public void setIssuingBankName(String issuingBankName) {
        this.issuingBankName = issuingBankName;
    }

    public void setCardScheme(String cardScheme) {
        this.cardScheme = cardScheme;
    }

    public void setUserMobileNo(String userMobileNo) {
        this.userMobileNo = userMobileNo;
    }

    public String getRrnCode() {
        return rrnCode;
    }

    public Money getAmount() {
        return amount;
    }

    public String getPayMethod() {
        return payMethod;
    }

    public String getMaskedCardNumber() {
        return maskedCardNumber;
    }

    public String getVirtualPaymentAddress() {
        return virtualPaymentAddress;
    }

    public String getMaskedBankAccountNumber() {
        return maskedBankAccountNumber;
    }

    public String getIssuingBankName() {
        return issuingBankName;
    }

    public String getCardScheme() {
        return cardScheme;
    }

    public String getUserMobileNo() {
        return userMobileNo;
    }

    public String getTxnAmount() {
        return txnAmount;
    }

    public void setTxnAmount(String txnAmount) {
        this.txnAmount = txnAmount;
    }

    public void setAddAndPay(Boolean addAndPay) {
        this.addAndPay = addAndPay;
    }

    public Boolean getAddAndPay() {
        return addAndPay;
    }

    public String getPrepaidCard() {
        return prepaidCard;
    }

    public void setPrepaidCard(String prepaidCard) {
        this.prepaidCard = prepaidCard;
    }

    public String getRefundTurnAroundTime() {
        return refundTurnAroundTime;
    }

    public void setRefundTurnAroundTime(String refundTurnAroundTime) {
        this.refundTurnAroundTime = refundTurnAroundTime;
    }

    @Override
    public String toString() {

        StringBuilder buf = new StringBuilder();
        buf.append("RefundChannelInfo [");
        buf.append(" rrnCode='").append(rrnCode).append('\'');
        buf.append(", amount='").append(amount).append('\'');
        buf.append(", payMethod='").append(payMethod).append('\'');
        buf.append(", maskedCardNumber='").append(maskedCardNumber).append('\'');
        buf.append(", ifscCode='").append(ifscCode).append('\'');
        buf.append(", virtualPaymentAddress='").append(virtualPaymentAddress).append('\'');
        buf.append(", maskedBankAccountNumber='").append(maskedBankAccountNumber).append('\'');
        buf.append(", issuingBankName='").append(issuingBankName).append('\'');
        buf.append(", cardScheme='").append(cardScheme).append('\'');
        buf.append(", userMobileNo='").append(userMobileNo).append('\'');
        buf.append(", txnAmount='").append(txnAmount).append('\'');
        buf.append(", addAndPay='").append(addAndPay).append('\'');
        buf.append(", prePaidCard='").append(prepaidCard).append('\'');
        buf.append(", refundTurnAroundTime='").append(refundTurnAroundTime).append('\'');
        buf.append("]");
        return buf.toString();
    }

}
