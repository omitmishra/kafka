package com.paytm.pgplus.notificationadapter.model.paymentNotify;

import java.io.Serializable;

public class DccPaymentDetail implements Serializable {

    private static final long serialVersionUID = -1408650064109007965L;

    // dcc order id return from the bank for each req
    private String dccId;

    // INR amount per unit home currency exc markup amt
    private String amountPerUnitForeignAmount;

    // 3 letter code
    private String foreignCurrencyCode;

    // eg $
    private String foreignCurrencySymbol;

    // total amt paid by cust in home curr inc markup amt
    private String foreignPayableAmount;

    // total amt paid by cust in home curr excl markup amt
    private String foreignPaymentAmount;

    // total markup amt charged by bank
    private String foreignMarkupAmount;

    // markup charged by the bank in % as conversion fee
    private String foreignMarkupRatePercentage;

    // expiration time stamp for dcc
    private String expirationTimestamp;

    // bank used for dcc conversion
    private String exchangeRateSourceName;

    // iso code for currency
    private String isoForeignCurrencyCode;

    // whether bank supports dcc or not
    private String dccOffered;

    private String foreignCurrencyName;

    private String dccExchangeRate;

    private String foreignConvenienceFee;

    private String orderAmount;

    private String convenienceFeeInInr;

    public String getDccId() {
        return dccId;
    }

    public void setDccId(String dccId) {
        this.dccId = dccId;
    }

    public String getAmountPerUnitForeignAmount() {
        return amountPerUnitForeignAmount;
    }

    public void setAmountPerUnitForeignAmount(String amountPerUnitForeignAmount) {
        this.amountPerUnitForeignAmount = amountPerUnitForeignAmount;
    }

    public String getForeignCurrencyCode() {
        return foreignCurrencyCode;
    }

    public void setForeignCurrencyCode(String foreignCurrencyCode) {
        this.foreignCurrencyCode = foreignCurrencyCode;
    }

    public String getForeignCurrencySymbol() {
        return foreignCurrencySymbol;
    }

    public void setForeignCurrencySymbol(String foreignCurrencySymbol) {
        this.foreignCurrencySymbol = foreignCurrencySymbol;
    }

    public String getForeignPayableAmount() {
        return foreignPayableAmount;
    }

    public void setForeignPayableAmount(String foreignPayableAmount) {
        this.foreignPayableAmount = foreignPayableAmount;
    }

    public String getForeignPaymentAmount() {
        return foreignPaymentAmount;
    }

    public void setForeignPaymentAmount(String foreignPaymentAmount) {
        this.foreignPaymentAmount = foreignPaymentAmount;
    }

    public String getForeignMarkupAmount() {
        return foreignMarkupAmount;
    }

    public void setForeignMarkupAmount(String foreignMarkupAmount) {
        this.foreignMarkupAmount = foreignMarkupAmount;
    }

    public String getForeignMarkupRatePercentage() {
        return foreignMarkupRatePercentage;
    }

    public void setForeignMarkupRatePercentage(String foreignMarkupRatePercentage) {
        this.foreignMarkupRatePercentage = foreignMarkupRatePercentage;
    }

    public String getExpirationTimestamp() {
        return expirationTimestamp;
    }

    public void setExpirationTimestamp(String expirationTimestamp) {
        this.expirationTimestamp = expirationTimestamp;
    }

    public String getExchangeRateSourceName() {
        return exchangeRateSourceName;
    }

    public void setExchangeRateSourceName(String exchangeRateSourceName) {
        this.exchangeRateSourceName = exchangeRateSourceName;
    }

    public String getIsoForeignCurrencyCode() {
        return isoForeignCurrencyCode;
    }

    public void setIsoForeignCurrencyCode(String isoForeignCurrencyCode) {
        this.isoForeignCurrencyCode = isoForeignCurrencyCode;
    }

    public String getDccOffered() {
        return dccOffered;
    }

    public void setDccOffered(String dccOffered) {
        this.dccOffered = dccOffered;
    }

    public String getForeignCurrencyName() {
        return foreignCurrencyName;
    }

    public void setForeignCurrencyName(String foreignCurrencyName) {
        this.foreignCurrencyName = foreignCurrencyName;
    }

    public String getDccExchangeRate() {
        return dccExchangeRate;
    }

    public void setDccExchangeRate(String dccExchangeRate) {
        this.dccExchangeRate = dccExchangeRate;
    }

    public String getForeignConvenienceFee() {
        return foreignConvenienceFee;
    }

    public void setForeignConvenienceFee(String foreignConvenienceFee) {
        this.foreignConvenienceFee = foreignConvenienceFee;
    }

    public String getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(String orderAmount) {
        this.orderAmount = orderAmount;
    }

    public String getConvenienceFeeInInr() {
        return convenienceFeeInInr;
    }

    public void setConvenienceFeeInInr(String convenienceFeeInInr) {
        this.convenienceFeeInInr = convenienceFeeInInr;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("DccPaymentDetailResponse {");
        sb.append(", dccOffered=").append(dccOffered);
        sb.append(", dccId=").append(dccId);
        sb.append(", amountPerUnitForeignAmount=").append(amountPerUnitForeignAmount);
        sb.append(", isoForeignCurrencyCode=").append(isoForeignCurrencyCode);
        sb.append(", foreignCurrencyCode='").append(foreignCurrencyCode);
        sb.append(", foreignCurrencySymbol=").append(foreignCurrencySymbol);
        sb.append(", foreignPayableAmount=").append(foreignPayableAmount);
        sb.append(", foreignPaymentAmount=").append(foreignPaymentAmount);
        sb.append(", foreignMarkupAmount=").append(foreignMarkupAmount);
        sb.append(", foreignMarkupRatePercentage=").append(foreignMarkupRatePercentage);
        sb.append(", expirationTimestamp=").append(expirationTimestamp);
        sb.append(", exchangeRateSourceName").append(exchangeRateSourceName);
        sb.append(", foreignCurrencyName=").append(foreignCurrencyName);
        sb.append(", foreignConvenienceFee=").append(foreignConvenienceFee);
        sb.append(", orderAmount=").append(orderAmount);
        sb.append(", convenienceFeeInInr=").append(convenienceFeeInInr);
        sb.append('}');
        return sb.toString();
    }
}

