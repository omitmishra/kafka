package com.paytm.pgplus.notificationadapter.service.impl;

import com.paytm.pg.dto.acquiring.FundBackNotifyDTO;
import com.paytm.pgplus.notificationadapter.config.ApplicationConfig;
import com.paytm.pgplus.notificationadapter.helper.AdapterThreadContextHelper;
import com.paytm.pgplus.notificationadapter.helper.DateTimeFormatter;
import com.paytm.pgplus.notificationadapter.helper.JsonMapper;
import com.paytm.pgplus.notificationadapter.helper.PayloadHelperService;
import com.paytm.pgplus.notificationadapter.http.service.impl.AdapterClientImpl;
import com.paytm.pgplus.notificationadapter.model.InputUserInfo;
import com.paytm.pgplus.notificationadapter.model.Money;
import com.paytm.pgplus.notificationadapter.model.fundbackNotify.FundbackRequestBody;
import com.paytm.pgplus.notificationadapter.model.paymentNotify.RefundChannelInfo;
import com.paytm.pgplus.notificationadapter.service.IProcessNotificationAdapterService;
import com.paytm.pgplus.notificationadapter.util.NotificationAdapterConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service(value = "fundBackNotifyServiceImpl")
public class FundbackNotifyServiceImpl implements IProcessNotificationAdapterService {

    private static final Logger log = LoggerFactory.getLogger(FundbackNotifyServiceImpl.class);

    @Autowired
    AdapterClientImpl adapterClientImpl;

    @Autowired
    PayloadHelperService payloadHelperService;

    @Autowired
    ApplicationConfig applicationConfig;

    public Runnable createNotifierJob(final String kafkaPayload){
        return new Runnable() {
            @Override
            public void run() {
                if (null != kafkaPayload){
                    try{
                        ThreadContext.clearAll();
                        FundbackRequestBody fundbackRequestBody = processFundbackNotifyDTO(kafkaPayload);
                        AdapterThreadContextHelper.setThreadContext(fundbackRequestBody.getAcquirementId(),
                                fundbackRequestBody.getMerchantTransId(), "FundbackNotify");
                        if(applicationConfig.isCheckForShadowMerchant() && fundbackRequestBody.getMerchantId().matches(".*[A-Za-z].*") && fundbackRequestBody.getMerchantId().matches(".*[0-9].*") && fundbackRequestBody.getMerchantId().matches("[A-Za-z0-9]*"))
                        {
                            log.info("Shadow Request received for mid:{}",fundbackRequestBody.getMerchantId());
                        }else {
                            adapterClientImpl.processFundbackNotify(payloadHelperService.getFundbackNotifyPayload(fundbackRequestBody));
                        }
                    } catch (Exception e){
                        log.error("Some Exception {} occurred during mapping of fundbackNotifyDTO to fundbackRequestBody for payload: {}", e,kafkaPayload);
                    }
                } else {
                    log.error("Payload can't be null for fundbackNotify");
                }
            }
        };
    }

    private FundbackRequestBody processFundbackNotifyDTO(String payload) throws Exception{
        FundbackRequestBody fundbackRequestBody = new FundbackRequestBody();
        try{
            FundBackNotifyDTO fundBackNotifyDTO = JsonMapper.mapJsonToObject(payload, FundBackNotifyDTO.class);
            fundbackRequestBody.setAcquirementId(fundBackNotifyDTO.getAcqId());
            fundbackRequestBody.setMerchantTransId(fundBackNotifyDTO.getMerchantTransId());
            fundbackRequestBody.setFundBackReason(fundBackNotifyDTO.getFundBackReason());
            fundbackRequestBody.setDestination(fundBackNotifyDTO.getDestination());
            setFundBackChannelInfoList(fundbackRequestBody, fundBackNotifyDTO);
            fundbackRequestBody.setMerchantName(fundBackNotifyDTO.getMerchantName());
            fundbackRequestBody.setResultInfo(fundBackNotifyDTO.getResultInfo());
            String orderExtendInfo = JsonMapper.mapObjectToJson(fundBackNotifyDTO.getOrderExtendInfo());
            fundbackRequestBody.setOrderExtendInfo(orderExtendInfo);
            Money orderAmount = new Money();
            if (fundBackNotifyDTO.getOrderAmount() != null) {
                orderAmount.setValue(fundBackNotifyDTO.getOrderAmount().getCurrencyValue());
                if (fundBackNotifyDTO.getOrderAmount().getCurrency() != null)
                    orderAmount.setCurrency(fundBackNotifyDTO.getOrderAmount().getCurrency().getCurrencyCode());
            }
            fundbackRequestBody.setOrderAmount(orderAmount);
            if(null == fundBackNotifyDTO.getAdditionalMetaInfo()){
                throw new Exception("Additional Meta info not Found!");
            }
            String merchantId=fundBackNotifyDTO.getAdditionalMetaInfo().get(NotificationAdapterConstants.ALIPAY_MID);

            if(StringUtils.isBlank(merchantId)){
                throw new Exception("Merchant Id can't be blank!");
            }
            fundbackRequestBody.setMerchantId(merchantId);
            fundbackRequestBody.setProductCode(fundBackNotifyDTO.getProductCode());
            fundbackRequestBody.setContractId(fundBackNotifyDTO.getContractId());
            if (StringUtils.isNotBlank(fundBackNotifyDTO.getCreateOrderTime())){
                fundbackRequestBody.setCreateOrderTime(DateTimeFormatter.getISO861DateTimeStringWithoutMillis(fundBackNotifyDTO.getCreateOrderTime()));
            } else {
                log.error("createOrderTime cannot be blank !");
                throw new Exception();
            }
            fundbackRequestBody.setPwpCategory(fundBackNotifyDTO.getPwpCategory());
            InputUserInfo buyerInfo = new InputUserInfo();
            if (fundBackNotifyDTO.getBuyerInfo() != null){
                buyerInfo.setUserId(fundBackNotifyDTO.getBuyerInfo().getUserId());
                buyerInfo.setExternalUserId(fundBackNotifyDTO.getBuyerInfo().getExternalUserId());
                buyerInfo.setExternalUserType(fundBackNotifyDTO.getBuyerInfo().getExternalUserType());
                buyerInfo.setNickname(fundBackNotifyDTO.getBuyerInfo().getNickname());
            }
            fundbackRequestBody.setBuyerInfo(buyerInfo);

        } catch (Exception e){
            throw e;
        }
        return fundbackRequestBody;
    }

    private void setFundBackChannelInfoList(FundbackRequestBody fundbackRequestBody, FundBackNotifyDTO fundBackNotifyDTO) throws Exception{
        try {
            List<RefundChannelInfo> fundBackChannelInfoList = new ArrayList<>();
            for(com.paytm.pg.common.structures.RefundChannelInfo refundChannelInfo : fundBackNotifyDTO.getFundBackChannelInfo()){
                RefundChannelInfo refundChannelInfo1 = new RefundChannelInfo();
                refundChannelInfo1.setRrnCode(refundChannelInfo.getRrnCode());
                //AddnPay not found in DTO
                refundChannelInfo1.setAddAndPay(false);
                Money amount = new Money();
                if (refundChannelInfo.getAmount() != null) {
                    amount.setValue(refundChannelInfo.getAmount().getValue().toString());
                    if (refundChannelInfo.getAmount().getCurrency() != null)
                        amount.setCurrency(refundChannelInfo.getAmount().getCurrency());
                }
                refundChannelInfo1.setAmount(amount);
                refundChannelInfo1.setPayMethod(refundChannelInfo.getPayMethod());
                refundChannelInfo1.setMaskedCardNumber(refundChannelInfo.getMaskedCardNumber());
                refundChannelInfo1.setVirtualPaymentAddress(refundChannelInfo.getVirtualPaymentAddress());
                refundChannelInfo1.setMaskedBankAccountNumber(refundChannelInfo.getMaskedBankAccountNumber());
                refundChannelInfo1.setIssuingBankName(refundChannelInfo.getIssuingBankName());
                refundChannelInfo1.setCardScheme(refundChannelInfo.getCardScheme());
                refundChannelInfo1.setUserMobileNo(refundChannelInfo.getUserMobileNo());
                //refundChannelInfo1.setTxnAmount(refundChannelInfo.get); txnAmount not coming in live requests
                refundChannelInfo1.setStatus(refundChannelInfo.getStatus());
                refundChannelInfo1.setIfscCode(refundChannelInfo.getIfscCode());
                refundChannelInfo1.setPrepaidCard(refundChannelInfo.getPrepaidCard());
                refundChannelInfo1.setRefundTurnAroundTime(DateTimeFormatter.getISO861DateTimeStringWithoutMillis(refundChannelInfo.getRefundTurnAroundTime()));
                refundChannelInfo1.setBankCode(refundChannelInfo.getIssuerBankInstCode()); //this mapping a lil unclear
                fundBackChannelInfoList.add(refundChannelInfo1);
            }
            fundbackRequestBody.setFundBackChannelInfoList(fundBackChannelInfoList);
        } catch (Exception e){
            log.error("Exception occurred in setFundBackChannelInfoList :", e);
            throw e;
        }
    }
}
