package com.paytm.pgplus.notificationadapter.service.impl;

import com.paytm.pgplus.notificationadapter.helper.AdapterThreadContextHelper;
import com.paytm.pgplus.notificationadapter.http.service.impl.AdapterClientImpl;
import com.paytm.pgplus.notificationadapter.service.IProcessNotificationAdapterService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value = "processRetryFundbackNotifyServiceImpl")
public class ProcessRetryFundbackNotifyServiceImpl implements IProcessNotificationAdapterService {
    private static final Logger log= LoggerFactory.getLogger(ProcessRetryFundbackNotifyServiceImpl.class);

    @Autowired
    AdapterClientImpl adapterClient;

    @Override
    public Runnable createNotifierJob(String fundbackRequestBody){
        return new Runnable() {
            @Override
            public void run() {
                try{
                    AdapterThreadContextHelper.setThreadContextForRetry(fundbackRequestBody,"FundbackNotifyRetry");
                    adapterClient.processRetryFundbackNotify(fundbackRequestBody);
                } catch (Exception e){
                    log.error("Exception : {} occurred while processing fundbackNotify retry request:{}",e.getMessage(),fundbackRequestBody);
                }
            }
        };
    }
}
