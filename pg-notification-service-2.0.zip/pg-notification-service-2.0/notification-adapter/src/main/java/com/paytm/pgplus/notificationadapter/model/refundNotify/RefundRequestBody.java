package com.paytm.pgplus.notificationadapter.model.refundNotify;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pg.common.structures.ResultInfo;
import com.paytm.pgplus.notificationadapter.helper.JsonMapper;
import com.paytm.pgplus.notificationadapter.model.AcquirementRequestBody;
import com.paytm.pgplus.notificationadapter.model.AgentInfoPeon;
import com.paytm.pgplus.notificationadapter.model.Money;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import java.util.Collections;
import java.util.Map;


@JsonIgnoreProperties(ignoreUnknown = true)
public class RefundRequestBody extends AcquirementRequestBody {

    /**
     * Serial version UID
     */
    private static final long serialVersionUID = 5404695856728945364L;

    @NotBlank(message = "{notblank}")
    @Length(max = 64, message = "{lengthlimit}")
    private String refundId;

    private Money orderAmount;

    private Money refundAmount;

    private String createOrderTime;

    private String refundApplyTime;

    private String refundPrepareSuccessTime;

    @NotNull(message = "{notnull}")
    @Valid
    private ResultInfo refundResult;

    private String extendInfo;

    private String orderExtendInfo;

    private String refundReason;

    private AgentInfoPeon agentInfo;

    private String productCode;

    private String merchantId;

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    /**
     * @return the refundId
     */
    public String getRefundId() {
        return refundId;
    }

    /**
     * @param refundId
     *            the refundId to set
     */
    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }

    /**
     * @return the refundAmount
     */
    public Money getRefundAmount() {
        return refundAmount;
    }

    /**
     * @param refundAmount
     *            the refundAmount to set
     */
    public void setRefundAmount(Money refundAmount) {
        this.refundAmount = refundAmount;
    }

    /**
     * @return the refundApplyTime
     */
    public String getRefundApplyTime() {
        return refundApplyTime;
    }

    /**
     * @param refundApplyTime
     *            the refundApplyTime to set
     */
    public void setRefundApplyTime(String refundApplyTime) {
        this.refundApplyTime = refundApplyTime;
    }

    /**
     * @return the refundResult
     */
    public ResultInfo getRefundResult() {
        return refundResult;
    }

    /**
     * @param refundResult
     *            the refundResult to set
     */
    public void setRefundResult(ResultInfo refundResult) {
        this.refundResult = refundResult;
    }

    public Money getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(Money orderAmount) {
        this.orderAmount = orderAmount;
    }

    public String getCreateOrderTime() {
        return createOrderTime;
    }

    public void setCreateOrderTime(String createOrderTime) {
        this.createOrderTime = createOrderTime;
    }

    public String getRefundPrepareSuccessTime() {
        return refundPrepareSuccessTime;
    }

    public void setRefundPrepareSuccessTime(String refundPrepareSuccessTime) {
        this.refundPrepareSuccessTime = refundPrepareSuccessTime;
    }

    @Override
    public String getMerchantTransId() {
        return merchantTransId;
    }

    @Override
    public void setMerchantTransId(String merchantTransId) {
        this.merchantTransId = merchantTransId;
    }

    public String getExtendInfo() {
        return extendInfo;
    }

    public void setExtendInfo(String extendInfo) {
        this.extendInfo = extendInfo;
    }

//    public Map<String, String> getExtendInfoMap() {
//        try {
//            if (StringUtils.isNotBlank(extendInfo)) {
//                return JsonMapper.mapJsonToObject(extendInfo, Map.class);
//            }
//        } catch (final Exception e) {
//        }
//        return Collections.emptyMap();
//    }

    public void setOrderExtendInfo(String orderExtendInfo) {
        this.orderExtendInfo = orderExtendInfo;
    }

    public String getOrderExtendInfo() {

        return orderExtendInfo;

    }
//    public Map<String, Object> obtainOrderExtendInfoMap() {
//        try {
//            if (StringUtils.isNotBlank(orderExtendInfo)) {
//                return JsonMapper.mapJsonToObject(orderExtendInfo, Map.class);
//            }
//        } catch (final Exception e) {
//        }
//        return Collections.emptyMap();
//    }

    public String getRefundReason() {
        return refundReason;
    }

    public void setRefundReason(String refundReason) {
        this.refundReason = refundReason;
    }

    public AgentInfoPeon getAgentInfo() {
        return agentInfo;
    }

    public void setAgentInfo(AgentInfoPeon agentInfo) {
        this.agentInfo = agentInfo;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("RefundRequestBody{");
        sb.append("acquirementId='").append(acquirementId).append('\'');
        sb.append(", createOrderTime='").append(createOrderTime).append('\'');
        sb.append(", merchantTransId='").append(merchantTransId).append('\'');
        sb.append(", merchantTransId='").append(merchantTransId).append('\'');
        sb.append(", orderAmount=").append(orderAmount);
        sb.append(", refundAmount=").append(refundAmount);
        sb.append(", refundApplyTime='").append(refundApplyTime).append('\'');
        sb.append(", refundId='").append(refundId).append('\'');
        sb.append(", refundPrepareSuccessTime='").append(refundPrepareSuccessTime).append('\'');
        sb.append(", refundResult=").append(refundResult);
        sb.append(", refundReason=").append(refundReason);
        sb.append(", agentInfo=").append(agentInfo);
        sb.append(", productCode=").append(productCode);
        sb.append(", merchantId=").append(merchantId);
        sb.append('}');
        return sb.toString();
    }

}

