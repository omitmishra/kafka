package com.paytm.pgplus.notificationadapter.helper;

import com.paytm.pgplus.notificationadapter.config.SignatureConfig;
import com.paytm.pgplus.notificationadapter.model.closeNotify.CloseNotifyRequestBody;
import com.paytm.pgplus.notificationadapter.model.fundbackNotify.FundbackRequestBody;
import com.paytm.pgplus.notificationadapter.model.paymentNotify.PaymentNotifyRequestBody;
import com.paytm.pgplus.notificationadapter.model.refundNotify.RefundRequestBody;
import com.paytm.pgplus.notificationadapter.model.refundSuccessNotify.RefundSuccessRequestBody;
import com.paytm.pgplus.notificationadapter.model.webFormContextNotify.WebFormContextNotifyRequestBody;
import com.paytm.pgplus.notificationadapter.signature.SignatureServiceHelper;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class PayloadHelperService {

    @Autowired
    private SignatureConfig signatureConfig;

    private static final Logger log = LoggerFactory.getLogger(PayloadHelperService.class);

    public String getPaymentNotifyPayload(PaymentNotifyRequestBody paymentNotifyRequestBody){
        JSONObject body = new JSONObject(paymentNotifyRequestBody);
        JSONObject payload = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject head = new JSONObject();
        {
            head.put("version", "1.1.4");
            head.put("function", "alipayplus.acquiring.order.paymentNotify");
            head.put("clientId", "2016030715243903536806");
            head.put("reqTime", DateTimeFormatter.getISO861DateTimeString(new Date()));
            head.put("reqMsgId", paymentNotifyRequestBody.getAcquirementId().concat(DateTimeFormatter.getISO861DateTimeString(new Date()))); // currently using combination of Date and acq id for mapping request and response
        }
        request.put("head", head);
        request.put("body", body);
        payload.put("request", request);
        payload.put("signature", getSignature(request.toString()));
        return payload.toString();
    }

    public String getWebFormContextNotifyPayload(WebFormContextNotifyRequestBody webFormContextNotifyRequestBody){
        JSONObject body = new JSONObject(webFormContextNotifyRequestBody);
        JSONObject payload = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject head = new JSONObject();
        {
            head.put("version", "1.1.4");
            head.put("function", "alipayplus.payment.cashier.webFormContextNotify");
            head.put("clientId", "2016030715243903536806");
            head.put("reqTime", DateTimeFormatter.getISO861DateTimeString(new Date()));
            head.put("reqMsgId", webFormContextNotifyRequestBody.getTransId().concat(DateTimeFormatter.getISO861DateTimeString(new Date()))); // currently using combination of Date and acq id for mapping request and response
        }
        request.put("head", head);
        request.put("body", body);
        payload.put("request", request);
        payload.put("signature", getSignature(request.toString()));
        return payload.toString();
    }

    public String getCloseNotifyPayload(CloseNotifyRequestBody closeNotifyRequestBody){
        JSONObject body = new JSONObject(closeNotifyRequestBody);
        JSONObject payload = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject head = new JSONObject();
        {
            head.put("version", "1.1.4");
            head.put("function", "alipayplus.acquiring.order.closeNotify");
            head.put("clientId", "2016030715243903536806");
            head.put("reqTime", DateTimeFormatter.getISO861DateTimeString(new Date()));
            head.put("reqMsgId", closeNotifyRequestBody.getAcquirementId().concat(DateTimeFormatter.getISO861DateTimeString(new Date()))); //currently using combination of Date and acq id for mapping request and response
        }
        request.put("head", head);
        request.put("body", body);
        payload.put("request", request);
        payload.put("signature", getSignature(request.toString()));
        return payload.toString();
    }

    public String getRefundNotifyPayload(RefundRequestBody refundRequestBody){
        JSONObject body = new JSONObject(refundRequestBody);
        JSONObject payload = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject head = new JSONObject();
        {
            head.put("version", "1.1.4");
            head.put("function", "alipayplus.acquiring.refund.refundNotify");
            head.put("clientId", "2016030715243903536806");
            head.put("reqTime", DateTimeFormatter.getISO861DateTimeString(new Date()));
            head.put("reqMsgId", refundRequestBody.getAcquirementId().concat(DateTimeFormatter.getISO861DateTimeString(new Date()))); // currently using combination of Date and acq id for mapping request and response
        }
        request.put("head", head);
        request.put("body", body);
        payload.put("request", request);
        payload.put("signature", getSignature(request.toString()));
        return payload.toString();
    }

    public String getRefundSuccessNotifyPayload(RefundSuccessRequestBody refundSuccessRequestBody){
        JSONObject body = new JSONObject(refundSuccessRequestBody);
        JSONObject payload = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject head = new JSONObject();
        {
            head.put("version", "1.1.4");
            head.put("function", "alipayplus.acquiring.refund.refundSuccessNotify");
            head.put("clientId", "2016030715243903536806");
            head.put("reqTime", DateTimeFormatter.getISO861DateTimeString(new Date()));
            head.put("reqMsgId",refundSuccessRequestBody.getAcquirementId().concat(DateTimeFormatter.getISO861DateTimeString(new Date())));//currently using combination of Date and acq id for mapping request and response
        }
        request.put("head", head);
        request.put("body", body);
        payload.put("request", request);
        payload.put("signature", getSignature(request.toString()));
        return payload.toString();
    }

    public String getFundbackNotifyPayload(FundbackRequestBody fundbackRequestBody){
        JSONObject body = new JSONObject(fundbackRequestBody);
        JSONObject payload = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject head = new JSONObject();
        {
            head.put("version", "1.1.4");
            head.put("function", "alipayplus.acquiring.order.fundBackNotify");
            head.put("clientId", "2016030715243903536806");
            head.put("reqTime", DateTimeFormatter.getISO861DateTimeString(new Date()));
            head.put("reqMsgId",fundbackRequestBody.getAcquirementId().concat(DateTimeFormatter.getISO861DateTimeString(new Date())));//currently using combination of Date and acq id for mapping request and response
        }
        request.put("head", head);
        request.put("body", body);
        payload.put("request", request);
        payload.put("signature", getSignature(request.toString()));
        return payload.toString();
    }

    public String getSignature(String body){
        String sig = "";
        try {
            SignatureServiceHelper  signatureServiceHelper=  SignatureServiceHelper.getInstance();
            sig= signatureServiceHelper.signApiRequest(body,signatureConfig.getShaKey());
        }catch (Exception e){
            log.error("Some exception occurred in generating Signature", e);
        }
        return sig;
    }


}
