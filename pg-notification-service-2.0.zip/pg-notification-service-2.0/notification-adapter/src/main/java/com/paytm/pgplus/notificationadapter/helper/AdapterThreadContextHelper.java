package com.paytm.pgplus.notificationadapter.helper;


import com.paytm.pgplus.notificationadapter.service.impl.ProcessRetryRefundSuccessNotifyServiceImpl;
import org.apache.logging.log4j.ThreadContext;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AdapterThreadContextHelper {

    private static final Logger log= LoggerFactory.getLogger(AdapterThreadContextHelper.class);

    public static void setThreadContext(final String TID,final String OID,final String type){
        ThreadContext.clearAll();
        ThreadContext.put("TID",TID);
        ThreadContext.put("OID",OID);
        ThreadContext.put("Type",type);
    }

    public static void setThreadContextForRetry(final String body,final String type) {
        try {
            JSONObject jsonObject = new JSONObject(body);
            JSONObject requestJson = jsonObject.getJSONObject("request");
            JSONObject bodyJson = requestJson.getJSONObject("body");
            ThreadContext.clearAll();
            ThreadContext.put("TID", bodyJson.getString("acquirementId"));
            ThreadContext.put("OID", bodyJson.getString("merchantTransId"));
            ThreadContext.put("Type",type);
        }catch (Exception e){
            log.error("Exception : {} ,occurred while setting ThreadContext for retry request :{}",e,body);
        }

    }

    public static void setThreadContextForWebContextRetry(final String body){
        try{
            JSONObject jsonObject = new JSONObject(body);
            JSONObject requestJson = jsonObject.getJSONObject("request");
            JSONObject bodyJson = requestJson.getJSONObject("body");
            ThreadContext.clearAll();
            ThreadContext.put("TID", bodyJson.getString("transId"));
            ThreadContext.put("OID", null);
            ThreadContext.put("Type","WebFormContextNotifyRetry");
        }catch (Exception e){
            log.error("Exception : {} ,occurred while setting ThreadContext for webFormNotify retry request :{}",e,body);
        }
    }

}
