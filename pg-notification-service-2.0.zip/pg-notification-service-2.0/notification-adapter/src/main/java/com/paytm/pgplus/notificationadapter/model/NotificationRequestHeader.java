package com.paytm.pgplus.notificationadapter.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;


@JsonIgnoreProperties(ignoreUnknown = true)
public class NotificationRequestHeader implements Serializable {
    /**
     * Serial version uid
     */
    private static final long serialVersionUID = 5560788360596434059L;

    /**
     * SPI version
     */
    @NotBlank(message = "{notblank}")
    @Length(max = 8, message = "{lengthlimit}")
    private String version;

    /**
     * SPI interface
     */
    @NotBlank(message = "{notblank}")
    @Length(max = 128, message = "{lengthlimit}")
    private String function;

    /**
     * provided by alipayplus, used to identify partner and application system
     */
    @Length(max = 32, message = "{lengthlimit}")
    private String clientId;

    /**
     * Request time
     */
    @NotBlank(message = "{notblank}")
    private String reqTime;

    /**
     * the sequence id of the request
     */
    @NotBlank(message = "{notblank}")
    @Length(max = 64, message = "{lengthlimit}")
    private String reqMsgId;

    private String markuid;

    /**
     * @return the version
     */
    public String getVersion() {
        return version;
    }

    /**
     * @param version
     *            the version to set
     */
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * @return the function
     */
    public String getFunction() {
        return function;
    }

    /**
     * @param function
     *            the function to set
     */
    public void setFunction(String function) {
        this.function = function;
    }

    /**
     * @return the appId
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * @param appId
     *            the appId to set
     */
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    /**
     * @return the reqTime
     */
    public String getReqTime() {
        return reqTime;
    }

    /**
     * @param reqTime
     *            the reqTime to set
     */
    public void setReqTime(String reqTime) {
        this.reqTime = reqTime;
    }

    /**
     * @return the reqMsgId
     */
    public String getReqMsgId() {
        return reqMsgId;
    }

    /**
     * @param reqMsgId
     *            the reqMsgId to set
     */
    public void setReqMsgId(String reqMsgId) {
        this.reqMsgId = reqMsgId;
    }

    public String getMarkuid() {
        return markuid;
    }

    public void setMarkuid(String markuid) {
        this.markuid = markuid;
    }
}
