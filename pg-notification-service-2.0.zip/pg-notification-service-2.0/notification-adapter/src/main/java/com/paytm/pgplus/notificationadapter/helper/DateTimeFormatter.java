package com.paytm.pgplus.notificationadapter.helper;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.util.Date;
import java.util.TimeZone;

public class DateTimeFormatter {

    private static final Logger LOGGER = LoggerFactory.getLogger(DateTimeFormatter.class);

    private static final TimeZone TIMEZONE;
    private static final String TIME_ZONE = "IST";
    private static final String ALIPAY_FORMAT = "yyyy-MM-dd'T'HH:mm:ssXXX";
    private static final String ALIPAY_FORMAT_MILLIS = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
    private static final FastDateFormat DATEFORMAT;
    private static final FastDateFormat DATEFORMAT_MILLIS;
    static {
        TIMEZONE = TimeZone.getTimeZone(TIME_ZONE);
        DATEFORMAT = FastDateFormat.getInstance(ALIPAY_FORMAT, TIMEZONE);
        DATEFORMAT_MILLIS = FastDateFormat.getInstance(ALIPAY_FORMAT_MILLIS, TIMEZONE);
    }


    public static String getISO861DateTimeString(Date date) {
       return DATEFORMAT.format(date);
    }

    public static String getISO861DateTimeStringWithoutMillis(String dateString) throws ParseException {
        String finalDate = dateString;
        if (StringUtils.isBlank(dateString)){
            return dateString;
        }
        try {
            Date date = DATEFORMAT_MILLIS.parse(dateString);
            finalDate = DATEFORMAT.format(date);
        } catch (Exception e){
            LOGGER.info("Unable to parse using DATEFORMAT_MILLIS, now trying with DATEFORMAT");
            try {
                Date date2 = DATEFORMAT.parse(dateString);
                finalDate = DATEFORMAT.format(date2);
            } catch (Exception e2){
                LOGGER.error("Could not format with DATEFORMAT also. Format unknown : ", e);
                throw e2;
            }
        }
        return finalDate;
    }



}
