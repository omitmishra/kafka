package com.paytm.pgplus.notificationadapter.config;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.util.concurrent.TimeUnit;

@Component
@EnableKafka
public class KafkaProducer {

    @Autowired
    @Qualifier("kafkaProducerTemplate")
    private KafkaTemplate<String, String> kafkaTemplate;

    private static final Logger log= LoggerFactory.getLogger(KafkaProducer.class);

    /**
     * @param topic the topic
     * @param unifiedData the unified data
     */
    @SneakyThrows
    public void publishMessage(String topic, String unifiedData) {
        try {
            log.info("Payload:{} sent for pushing to kafka retry topic :{}",unifiedData,topic);
            long startTime = System.currentTimeMillis();
            kafkaTemplate.send(topic, unifiedData).get(2L, TimeUnit.SECONDS);
            log.info("SendingMessage" + " [" + topic + "][" + unifiedData + "]");
            ThreadContext.put("PUBLISH_TIME", String.valueOf(System.currentTimeMillis() - startTime));
            log.info("Message Published");
            ThreadContext.clearAll();

        } catch (Exception exc) {
            log.error("Error while publishing", exc);
            throw exc;
        }
    }

    /***
     * message publisher
     * @param record
     */
    public void publishMessage(ProducerRecord record) {
        try {
            kafkaTemplate.send(record).get(2L, TimeUnit.SECONDS);
            log.info("SendingMessage" + " [" + record + "]");
        } catch (Exception exc) {
            log.error("Error while publishing", exc);
        }
    }

    public void sendMessage(String topic, String key, String unifiedData) {
        ListenableFuture<SendResult<String, String>> future = kafkaTemplate.send(topic, unifiedData);

        future.addCallback(
                new ListenableFutureCallback<SendResult<String, String>>() {

                    @Override
                    public void onSuccess(SendResult<String, String> result) {
                        log.info(
                                "Sent message=[{}] with offset=[{}]",
                                unifiedData,
                                result.getRecordMetadata().offset());
                    }

                    @Override
                    public void onFailure(Throwable ex) {
                        log.info("Unable to send message=[{}] due to : {}", unifiedData, ex.getMessage());
                    }
                });
    }
}
