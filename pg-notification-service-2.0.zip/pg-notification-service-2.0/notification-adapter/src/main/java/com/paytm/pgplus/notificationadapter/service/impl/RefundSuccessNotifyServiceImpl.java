package com.paytm.pgplus.notificationadapter.service.impl;

import com.paytm.pg.common.structures.ChannelInfoDTO;
import com.paytm.pg.common.structures.FundDetailInfoDTO;
import com.paytm.pg.dto.acquiring.RefundSuccessNotifyDTO;
import com.paytm.pg.dto.payments.FundDetailDTO;
import com.paytm.pgplus.notificationadapter.config.ApplicationConfig;
import com.paytm.pgplus.notificationadapter.helper.AdapterThreadContextHelper;
import com.paytm.pgplus.notificationadapter.helper.DateTimeFormatter;
import com.paytm.pgplus.notificationadapter.helper.JsonMapper;
import com.paytm.pgplus.notificationadapter.helper.PayloadHelperService;
import com.paytm.pgplus.notificationadapter.http.service.impl.AdapterClientImpl;
import com.paytm.pgplus.notificationadapter.model.AgentInfoPeon;
import com.paytm.pgplus.notificationadapter.model.InputUserInfo;
import com.paytm.pgplus.notificationadapter.model.Money;
import com.paytm.pgplus.notificationadapter.model.refundSuccessNotify.*;
import com.paytm.pgplus.notificationadapter.service.IProcessNotificationAdapterService;
import com.paytm.pgplus.notificationadapter.util.NotificationAdapterConstants;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service(value = "refundSuccessNotifyServiceImpl")
public class RefundSuccessNotifyServiceImpl implements IProcessNotificationAdapterService {
    private static final Logger log = LoggerFactory.getLogger(RefundSuccessNotifyServiceImpl.class);

    @Autowired
    AdapterClientImpl adapterClientImpl;

    @Autowired
    PayloadHelperService payloadHelperService;

    @Autowired
    ApplicationConfig applicationConfig;

    @Override
    public Runnable createNotifierJob(final String kafkaPayload){
        return new Runnable() {
            @Override
            public void run() {
                if(null != kafkaPayload){
                    try{
                        ThreadContext.clearAll();
                        RefundSuccessRequestBody body = processRefundSuccess(kafkaPayload);
                        AdapterThreadContextHelper.setThreadContext(body.getAcquirementId(), body.getMerchantTransId(), "RefundSuccessNotify");
                        if(applicationConfig.isCheckForShadowMerchant() && body.getMerchantId().matches(".*[A-Za-z].*") && body.getMerchantId().matches(".*[0-9].*") && body.getMerchantId().matches("[A-Za-z0-9]*"))
                        {
                            log.info("Shadow Request received for mid:{}",body.getMerchantId());
                        }else {
                            adapterClientImpl.processRefundSuccessNotify(payloadHelperService.getRefundSuccessNotifyPayload(body));
                        }
                    } catch (Exception e){
                        log.error("Exception occurred while processing RefundSuccessNotifyRequest:", e);
                    }
                } else {
                    log.error("Invalid request received for RefundSuccessNotify");
                }
            }
        };
    }

    RefundSuccessRequestBody processRefundSuccess(String kafkaPayload) throws Exception{
        RefundSuccessRequestBody refundSuccessRequestBody = new RefundSuccessRequestBody();
        try {
            RefundSuccessNotifyDTO refundSuccessNotifyDTO = JsonMapper.mapJsonToObject(kafkaPayload , RefundSuccessNotifyDTO.class);

            refundSuccessRequestBody.setAcquirementId(refundSuccessNotifyDTO.getAcquirementId());
            refundSuccessRequestBody.setMerchantTransId(refundSuccessNotifyDTO.getMerchantTransId());

            Money orderAmount = new Money();
            if (refundSuccessNotifyDTO.getOrderAmount() != null){
                orderAmount.setValue(String.valueOf(refundSuccessNotifyDTO.getOrderAmount().getCent()));
                if (refundSuccessNotifyDTO.getOrderAmount().getCurrency() != null)
                    orderAmount.setCurrency(refundSuccessNotifyDTO.getOrderAmount().getCurrency().getCurrencyCode());
            }
            refundSuccessRequestBody.setOrderAmount(orderAmount);
            if(null == refundSuccessNotifyDTO.getAdditionalMetaInfo()){
                throw new Exception("Additional Meta info not Found!");
            }
            String merchantId=refundSuccessNotifyDTO.getAdditionalMetaInfo().get(NotificationAdapterConstants.ALIPAY_MID);
            if(StringUtils.isBlank(merchantId)){
                throw new Exception("Merchant Id can't be blank!");
            }
            refundSuccessRequestBody.setMerchantId(merchantId);
            refundSuccessRequestBody.setContractId(refundSuccessNotifyDTO.getContractId());
            refundSuccessRequestBody.setProductCode(refundSuccessNotifyDTO.getProductCode());
            if (StringUtils.isNotBlank(refundSuccessNotifyDTO.getCreateOrderTime())){
                refundSuccessRequestBody.setCreateOrderTime(DateTimeFormatter.getISO861DateTimeStringWithoutMillis(refundSuccessNotifyDTO.getCreateOrderTime()));
            } else {
                log.error("createOrderTime cannot be blank !");
                throw new Exception();
            }

            InputUserInfo inputUserInfo = new InputUserInfo();
            if (refundSuccessNotifyDTO.getBuyerInfo() != null){
                inputUserInfo.setUserId(refundSuccessNotifyDTO.getBuyerInfo().getUserId());
                inputUserInfo.setExternalUserId(refundSuccessNotifyDTO.getBuyerInfo().getExternalUserId());
                inputUserInfo.setExternalUserType(refundSuccessNotifyDTO.getBuyerInfo().getExternalUserType());
                inputUserInfo.setNickname(refundSuccessNotifyDTO.getBuyerInfo().getNickname());
            }
            refundSuccessRequestBody.setBuyerInfo(inputUserInfo);
            refundSuccessRequestBody.setMerchantRequestId(refundSuccessNotifyDTO.getMerchantRequestId());
            refundSuccessRequestBody.setRefundId(refundSuccessNotifyDTO.getRefundId());

            Money refundAmount = new Money();
            if (refundSuccessNotifyDTO.getRefundAmount() != null){
                refundAmount.setValue(String.valueOf(refundSuccessNotifyDTO.getRefundAmount().getCent()));
                if (refundSuccessNotifyDTO.getRefundAmount().getCurrency() != null)
                    refundAmount.setCurrency(refundSuccessNotifyDTO.getRefundAmount().getCurrency().getCurrencyCode());
            }
            refundSuccessRequestBody.setRefundAmount(refundAmount);
            if (StringUtils.isNotBlank(refundSuccessNotifyDTO.getRefundApplyTime())){
                refundSuccessRequestBody.setRefundApplyTime(DateTimeFormatter.getISO861DateTimeStringWithoutMillis(refundSuccessNotifyDTO.getRefundApplyTime()));
            } else {
                log.error("refundApplyTime cannot be blank !");
                throw new Exception();
            }
            refundSuccessRequestBody.setOffset(refundSuccessNotifyDTO.isOffset());
            if (StringUtils.isNotBlank(refundSuccessNotifyDTO.getRefundSuccessTime())){
                refundSuccessRequestBody.setRefundSuccessTime(DateTimeFormatter.getISO861DateTimeStringWithoutMillis(refundSuccessNotifyDTO.getRefundSuccessTime()));
            } else {
                log.error("refundSuccessTime cannot be blank !");
                throw new Exception();
            }
            refundSuccessRequestBody.setDestination(refundSuccessNotifyDTO.getDestination());
            setRefundFundChannelInfo(refundSuccessRequestBody, refundSuccessNotifyDTO.getChannelInfo());
            Money totalSuccessfulRefundedAmountOnOrder = new Money();
            if (refundSuccessNotifyDTO.getTotalSuccessfulRefundedAmountOnOrder() != null){
                totalSuccessfulRefundedAmountOnOrder.setValue(String.valueOf(refundSuccessNotifyDTO.getTotalSuccessfulRefundedAmountOnOrder().getCent()));
                if (refundSuccessNotifyDTO.getTotalSuccessfulRefundedAmountOnOrder().getCurrency() != null)
                    totalSuccessfulRefundedAmountOnOrder.setCurrency(refundSuccessNotifyDTO.getTotalSuccessfulRefundedAmountOnOrder().getCurrency().getCurrencyCode());
            }
            refundSuccessRequestBody.setTotalSuccessfulRefundedAmountOnOrder(totalSuccessfulRefundedAmountOnOrder);
            refundSuccessRequestBody.setRefundReason(refundSuccessNotifyDTO.getRefundReason());
            setRefundDetailInfoList(refundSuccessRequestBody, refundSuccessNotifyDTO);
            refundSuccessRequestBody.setReturnChargeToPayer(refundSuccessNotifyDTO.isReturnChargeToPayer());

            String extendInfo = JsonMapper.mapObjectToJson(refundSuccessNotifyDTO.getExtendInfo());
            refundSuccessRequestBody.setExtendInfo(extendInfo);
            String orderExtendInfo = JsonMapper.mapObjectToJson(refundSuccessNotifyDTO.getOrderExtendInfo());
            refundSuccessRequestBody.setOrderExtendInfo(orderExtendInfo);

            refundSuccessRequestBody.setRefundSuccessResult(refundSuccessNotifyDTO.getResultInfo());
            refundSuccessRequestBody.setRrnCode(refundSuccessNotifyDTO.getRrnCode());

            AgentInfoPeon agentInfoPeon = new AgentInfoPeon();
            if (refundSuccessNotifyDTO.getAgentInfo() != null){
                agentInfoPeon.setEmail(refundSuccessNotifyDTO.getAgentInfo().getEmail());
                agentInfoPeon.setEmployeeId(refundSuccessNotifyDTO.getAgentInfo().getEmployeeId());
                agentInfoPeon.setName(refundSuccessNotifyDTO.getAgentInfo().getName());
                agentInfoPeon.setPhoneNo(refundSuccessNotifyDTO.getAgentInfo().getPhoneNo());
            }
            refundSuccessRequestBody.setAgentInfo(agentInfoPeon);

        } catch (Exception e){
            throw e;
        }
        return refundSuccessRequestBody;
    }

    private void setRefundDetailInfoList(RefundSuccessRequestBody refundSuccessRequestBody, RefundSuccessNotifyDTO refundSuccessNotifyDTO) throws Exception{
        try{
            List<RefundDetailInfo> refundDetailInfoList = new ArrayList<>();
            for (FundDetailInfoDTO fundDetailInfoDTO : refundSuccessNotifyDTO.getDetailInfo()){
                RefundDetailInfo refundDetailInfo = new RefundDetailInfo();
                setChannelInfoList(refundDetailInfo, fundDetailInfoDTO.getChannelInfo());
                Money refundDetailAmount = new Money();
                if (fundDetailInfoDTO.getAmount() != null){
                    refundDetailAmount.setValue(String.valueOf(fundDetailInfoDTO.getAmount().getCent()));
                    if (fundDetailInfoDTO.getAmount().getCurrency() != null)
                        refundDetailAmount.setCurrency(fundDetailInfoDTO.getAmount().getCurrency().getCurrencyCode());
                }
                refundDetailInfo.setRefundDetailAmount(refundDetailAmount);
                refundDetailInfo.setDestination(fundDetailInfoDTO.getDestination());
                refundDetailInfoList.add(refundDetailInfo);
            }
            refundSuccessRequestBody.setRefundDetailInfoList(refundDetailInfoList);
        }catch (Exception e){
            log.error("Some exception occurred in setRefundDetailInfoList : ", e);
            throw e;
        }
    }

    private void setChannelInfoList(RefundDetailInfo refundDetailInfo, List<ChannelInfoDTO> channelInfo) throws Exception{
        try{
            List<RefundChannelInfo> channelInfoList = new ArrayList<>();
            for (ChannelInfoDTO channelInfoDTO : channelInfo){
                RefundChannelInfo refundChannelInfo = new RefundChannelInfo();
                refundChannelInfo.setRrnCode(channelInfoDTO.getRrnCode());
                refundChannelInfo.setAddAndPay(channelInfoDTO.isAddAndPay());
                Money amount = new Money();
                if (channelInfoDTO.getAmount() != null){
                    amount.setValue(String.valueOf(channelInfoDTO.getAmount().getCent()));
                    if (channelInfoDTO.getAmount().getCurrency() != null)
                        amount.setCurrency(channelInfoDTO.getAmount().getCurrency().getCurrencyCode());
                }
                refundChannelInfo.setAmount(amount);
                refundChannelInfo.setPayMethod(channelInfoDTO.getPayMethod());
                refundChannelInfo.setMaskedCardNumber(channelInfoDTO.getPayRequestMaskedCardNo());
                refundChannelInfo.setVirtualPaymentAddress(channelInfoDTO.getVirtualPaymentAddress());
                refundChannelInfo.setIssuingBankName(channelInfoDTO.getIssuerBank());
                refundChannelInfo.setUserMobileNo(channelInfoDTO.getUserMobileNo());
                refundChannelInfo.setStatus(channelInfoDTO.getStatus());
                if(null != channelInfoDTO.getRefundTurnAroundTime()){
                        DateFormat format=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
                        String refundTurnAroundTime=format.format(channelInfoDTO.getRefundTurnAroundTime());
                        refundChannelInfo.setRefundTurnAroundTime(refundTurnAroundTime);
                }
                channelInfoList.add(refundChannelInfo);
            }
            refundDetailInfo.setChannelInfoList(channelInfoList);
        } catch (Exception e){
            log.error("Some exception occurred in setChannelInfoList : ", e);
            throw e;
        }
    }

    private void setRefundFundChannelInfo(RefundSuccessRequestBody refundSuccessRequestBody, List<ChannelInfoDTO> channelInfo) throws Exception{
        try{
            List<FundChannelInfo> refundFundChannelInfo = new ArrayList<>();
            for (ChannelInfoDTO channelInfoDTO : channelInfo){
                FundChannelInfo fundChannelInfo = new FundChannelInfo();
                fundChannelInfo.setPayMethod(Enum.valueOf(PayMethodEnum.class, channelInfoDTO.getPayMethod()));
                fundChannelInfo.setCardCacheToken(channelInfoDTO.getCardCacheToken());
                //fundChannelInfo.setCardIndexNo(); not coming
                fundChannelInfo.setMaskedCardNo(channelInfoDTO.getPayRequestMaskedCardNo());
                fundChannelInfo.setExtSerialNo(channelInfoDTO.getExtSerialNo());
                fundChannelInfo.setGateway(channelInfoDTO.getGateway());
                fundChannelInfo.setServiceInstId(channelInfoDTO.getServiceInstId());
                fundChannelInfo.setAssetTool(channelInfoDTO.getAssetTool());
                fundChannelInfo.setSourceAssetTool(channelInfoDTO.getSourceAssetTool());

                Money amount = new Money();
                if (channelInfoDTO.getAmount() != null){
                    amount.setValue(String.valueOf(channelInfoDTO.getAmount().getCent()));
                    if (channelInfoDTO.getAmount().getCurrency() != null)
                        amount.setCurrency(channelInfoDTO.getAmount().getCurrency().getCurrencyCode());
                }
                fundChannelInfo.setAmount(amount);
                fundChannelInfo.setAccountNo(channelInfoDTO.getAccountNo());
                refundFundChannelInfo.add(fundChannelInfo);
            }
            refundSuccessRequestBody.setRefundFundChannelInfo(refundFundChannelInfo);
        }catch (Exception e){
            log.error("Some exception occurred in setRefundFundChannelInfo : ", e);
            throw e;
        }
    }
}
