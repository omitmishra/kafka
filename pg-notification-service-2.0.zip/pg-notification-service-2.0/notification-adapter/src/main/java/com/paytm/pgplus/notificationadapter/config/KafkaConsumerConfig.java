package com.paytm.pgplus.notificationadapter.config;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ConsumerAwareErrorHandler;
import org.springframework.kafka.listener.MessageListenerContainer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@EnableKafka
@Configuration
public class KafkaConsumerConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaConsumerConfig.class);

    @Value("${consumer.bootstrap.servers}")
    private String bootstrapAddress;

    @Value("${enable.auto.commit}")
    private boolean enableAutoCommit;

    @Value("${auto.commit.interval.ms}")
    private int autoCommitInterval;

    @Value("${session.timeout.ms}")
    private int sessionTimeOut;

    @Value("${heartbeat.interval.ms}")
    private int heartBeatInterval;

    @Value("${max.partition.fetch.bytes}")
    private int maxPartitionsFetchSize;

    @Value("${consumer.concurrency}")
    private int concurrency;



    @Bean
    public ConsumerFactory<String, String> consumerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        // Set this property, if auto commit should happen.
        props.put("enable.auto.commit",enableAutoCommit);

        // Auto commit interval, kafka would commit offset at this interval.
        props.put("auto.commit.interval.ms", autoCommitInterval);

        // This is how to control number of records being read in each poll
        props.put("max.partition.fetch.bytes",maxPartitionsFetchSize);

        // Set this if you want to always read from beginning.
        // props.put("auto.offset.reset", "earliest");

        props.put("heartbeat.interval.ms",heartBeatInterval);
        props.put("session.timeout.ms", sessionTimeOut);
        return new DefaultKafkaConsumerFactory<>(props);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        factory.setConcurrency(concurrency);
        factory.setErrorHandler(consumerAwareErrorHandler());
        //factory.set
        return factory;
    }

    @Bean
    public ConsumerAwareErrorHandler consumerAwareErrorHandler(){
        return new ConsumerAwareErrorHandler() {
            @Override
            public void handle(Exception e, ConsumerRecord<?, ?> consumerRecord, Consumer<?, ?> consumer) {

            }

            @Override
            public void handle(Exception thrownException, List<ConsumerRecord<?, ?>> data, Consumer<?, ?> consumer, MessageListenerContainer container) {
                String s = thrownException.getMessage().split("Error deserializing key/value for partition ")[1].split(". If needed, please seek past the record to continue consumption.")[0];
                String topic = s.split("-")[0];
                int offset = Integer.valueOf(s.split("offset ")[1]);
                int partition = Integer.valueOf(s.split("-")[1].split(" at")[0]);

                TopicPartition topicPartition = new TopicPartition(topic, partition);
                LOGGER.error("Exception : {} occurred while consuming from topic : {},partition : {}, offset : {}",
                        thrownException,topic,partition,offset);
                LOGGER.info("Skipping " + topic + " partition " + partition + " offset " + offset);
                consumer.seek(topicPartition, offset + 1);
            }

        };
    }

}