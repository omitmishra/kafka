package com.paytm.pgplus.notificationadapter.http.enums;

public interface ServiceUrl {
    String getFunctionalUrl();
}
