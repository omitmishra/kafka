package com.paytm.pgplus.notificationadapter.model.paymentNotify;

/**
 *
 */


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.paytm.pg.common.structures.ResultInfo;
import com.paytm.pgplus.notificationadapter.helper.JsonMapper;
import com.paytm.pgplus.notificationadapter.model.*;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * @author amit.dubey
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentNotifyRequestBody extends AcquirementRequestBody {

    /**
     * serial version UID
     */
    private static final long serialVersionUID = -7521004472800537742L;

    @NotBlank(message = "{notblank}")
    private String createdTime;

    @NotBlank(message = "{notblank}")
    private String merchantId;

    private String merchantName;

    @NotNull(message = "{notnull}")
    @Valid
    private Money orderAmount;

    private String orderStatus;

    @NotNull(message = "{notnull}")
    @Valid
    private PaymentView paymentView;

    private String orderExtendInfo;

    private String bizExtendInfo;

    @NotNull(message = "{notnull}")
    @Valid
    private ResultInfo payResult;

    private int requeCount;

    private String extendInfo;

    private String productCode;

    private String acquireMode;

    /**
     * when revoke happens, this field stands for related channel information
     */
    private RefundChannelInfo revokeChannelInfo;

    /**
     * seller info object for sms repayment
     */
    private InputUserInfo sellerInfo;

    public void setSellerInfo(InputUserInfo sellerInfo) {
        this.sellerInfo = sellerInfo;
    }

    public void setBuyerInfo(InputUserInfo buyerInfo) {
        this.buyerInfo = buyerInfo;
    }

    /**
     * buyer info object for sms repayment
     */
    private InputUserInfo buyerInfo;

    private String orderModifyExtendInfo;

    private List<SplitCommandInfo> splitCommandInfoList;

    /**
     * for settlement purpose
     */
    private String paidTime;

    /**
     * timeoutExtendInfo for Pre-Auth List<Map<String,String>>
     */
    private String timeoutExtendInfo;

    public String getTimeoutExtendInfo() {
        return timeoutExtendInfo;
    }

    public void setTimeoutExtendInfo(String timeoutExtendInfo) {
        this.timeoutExtendInfo = timeoutExtendInfo;
    }

    public OrderPricingInfo getOrderPricingInfo() {
        return orderPricingInfo;
    }

    public void setOrderPricingInfo(OrderPricingInfo orderPricingInfo) {
        this.orderPricingInfo = orderPricingInfo;
    }

    /**
     * extra parameter for MLV
     */
    private OrderPricingInfo orderPricingInfo;

    public RefundChannelInfo getRevokeChannelInfo() {
        return revokeChannelInfo;
    }

    public void setRevokeChannelInfo(RefundChannelInfo revokeChannelInfo) {
        this.revokeChannelInfo = revokeChannelInfo;
    }

    public InputUserInfo getSellerInfo() {
        return sellerInfo;
    }

    public InputUserInfo getBuyerInfo() {
        return buyerInfo;
    }

    /**
     * @return the paymentView
     */
    public PaymentView getPaymentView() {
        return paymentView;
    }

    /**
     * @param paymentView
     *            the paymentView to set
     */
    public void setPaymentView(PaymentView paymentView) {
        this.paymentView = paymentView;
    }

    /**
     * @return the createdTime
     */
    public String getCreatedTime() {
        return createdTime;
    }

    /**
     * @param createdTime
     *            the createdTime to set
     */
    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    /**
     * @return the merchantId
     */
    public String getMerchantId() {
        return merchantId;
    }

    /**
     * @param merchantId
     *            the merchantId to set
     */
    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    /**
     * @return the orderAmount
     */
    public Money getOrderAmount() {
        return orderAmount;
    }

    /**
     * @param orderAmount
     *            the orderAmount to set
     */
    public void setOrderAmount(Money orderAmount) {
        this.orderAmount = orderAmount;
    }

    /**
     * @return the orderExtendInfo
     */
    public String getOrderExtendInfo() {
        return orderExtendInfo;
    }

    /**
     * @param orderExtendInfo
     *            the orderExtendInfo to set
     */
    public void setOrderExtendInfo(String orderExtendInfo) {
        this.orderExtendInfo = orderExtendInfo;
    }

    /**
     * @return the payResult
     */
    public ResultInfo getPayResult() {
        return payResult;
    }

    /**
     * @param payResult
     *            the payResult to set
     */
    public void setPayResult(ResultInfo payResult) {
        this.payResult = payResult;
    }

    /**
     * @return the requeCount
     */
    public int getRequeCount() {
        return requeCount;
    }

    /**
     * @param requeCount
     *            the requeCount to set
     */
    public void setRequeCount(int requeCount) {
        this.requeCount = requeCount;
    }

    public String getBizExtendInfo() {
        return bizExtendInfo;
    }

    public String getExtendInfo() {
        return extendInfo;
    }

    public void setExtendInfo(String extendInfo) {
        this.extendInfo = extendInfo;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getOrderModifyExtendInfo() {
        return orderModifyExtendInfo;
    }

    public void setOrderModifyExtendInfo(String orderModifyExtendInfo) {
        this.orderModifyExtendInfo = orderModifyExtendInfo;
    }

    public String getAcquireMode() {
        return acquireMode;
    }

    public void setAcquireMode(String acquireMode) {
        this.acquireMode = acquireMode;
    }

    public List<SplitCommandInfo> getSplitCommandInfoList() {
        return splitCommandInfoList;
    }

    public void setSplitCommandInfoList(List<SplitCommandInfo> splitCommandInfoList) {
        this.splitCommandInfoList = splitCommandInfoList;
    }

    /**
     * @return
     */
    public String getPaidTime() {
        return paidTime;
    }

    /**
     * @param paidTime
     */
    public void setPaidTime(String paidTime) {
        this.paidTime = paidTime;
    }

    /*
     * method name modified from getOrderExtendInfoMap to
     * obtainOrderExtendInfoMap.
     *
     * any custom method name must not start with "get", as during serialization
     * all the methods starting with "get" are called which invoked this method
     * and since extendInfo should be a Map<String, Object> this method was
     * throwing a ClassCastException.
     */
//    public Map<String, String> obtainOrderExtendInfoMap() {
//        try {
//            if (StringUtils.isNotBlank(orderExtendInfo)) {
//                return JsonMapper.mapJsonToObject(orderExtendInfo, Map.class);
//            }
//        } catch (final JsonProcessingException e) {
//
//        }
//        return Collections.emptyMap();
//    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PaymentNotifyRequestBody{");
        sb.append("acquirementId='").append(acquirementId).append('\'');
        sb.append(", bizExtendInfo='").append(bizExtendInfo).append('\'');
        sb.append(", createdTime='").append(createdTime).append('\'');
        sb.append(", merchantId='").append(merchantId).append('\'');
        sb.append(", merchantName='").append(merchantName).append('\'');
        sb.append(", merchantTransId='").append(merchantTransId).append('\'');
        sb.append(", orderAmount=").append(orderAmount);
        sb.append(", orderStatus=").append(orderStatus);
        sb.append(", orderExtendInfo='").append(orderExtendInfo).append('\'');
        sb.append(", paymentView=").append(paymentView);
        sb.append(", payResult=").append(payResult);
        sb.append(", requeCount=").append(requeCount);
        sb.append(", extendInfo=").append(extendInfo);
        sb.append(", productCode=").append(productCode);
        sb.append(", revokeChannelInfo=").append(revokeChannelInfo);
        sb.append(", sellerInfo=").append(sellerInfo);
        sb.append(", buyerInfo=").append(buyerInfo);
        sb.append(", orderModifyExtendInfo='").append(orderModifyExtendInfo).append('\'');
        sb.append(", splitCommandInfoList='").append(splitCommandInfoList).append('\'');
        sb.append(", paidTime='").append(paidTime).append('\'');
        sb.append(", timeoutExtendInfo='").append(timeoutExtendInfo).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
}
