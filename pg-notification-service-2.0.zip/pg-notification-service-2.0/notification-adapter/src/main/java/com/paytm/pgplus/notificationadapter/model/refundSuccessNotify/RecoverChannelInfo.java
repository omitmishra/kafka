package com.paytm.pgplus.notificationadapter.model.refundSuccessNotify;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RecoverChannelInfo implements Serializable {

    private static final long serialVersionUID = 1324035214070643917L;
    private String esn;
    private String virtualPaymentAddress;
    private String serviceInstId;
    private String mbid;
    private String issuingBankName;
    private String cardScheme;
    private String rrnCode;
    private String payMethod;
    private String maskedBankAccountNumber;
    private String maskedCardNumber;
    private String userMobileNo;
    private String refundType;
    private String recoverSuccessTime;

    public String getRecoverSuccessTime() {
        return recoverSuccessTime;
    }

    public void setRecoverSuccessTime(String recoverSuccessTime) {
        this.recoverSuccessTime = recoverSuccessTime;
    }

    // Getter Methods

    public String getEsn() {
        return esn;
    }

    public String getVirtualPaymentAddress() {
        return virtualPaymentAddress;
    }

    public String getServiceInstId() {
        return serviceInstId;
    }

    public String getMbid() {
        return mbid;
    }

    public String getIssuingBankName() {
        return issuingBankName;
    }

    public String getCardScheme() {
        return cardScheme;
    }

    public String getRrnCode() {
        return rrnCode;
    }

    public String getPayMethod() {
        return payMethod;
    }

    public String getMaskedBankAccountNumber() {
        return maskedBankAccountNumber;
    }

    public String getMaskedCardNumber() {
        return maskedCardNumber;
    }

    public String getUserMobileNo() {
        return userMobileNo;
    }

    public String getRefundType() {
        return refundType;
    }

    // Setter Methods

    public void setEsn(String esn) {
        this.esn = esn;
    }

    public void setVirtualPaymentAddress(String virtualPaymentAddress) {
        this.virtualPaymentAddress = virtualPaymentAddress;
    }

    public void setServiceInstId(String serviceInstId) {
        this.serviceInstId = serviceInstId;
    }

    public void setMbid(String mbid) {
        this.mbid = mbid;
    }

    public void setIssuingBankName(String issuingBankName) {
        this.issuingBankName = issuingBankName;
    }

    public void setCardScheme(String cardScheme) {
        this.cardScheme = cardScheme;
    }

    public void setRrnCode(String rrnCode) {
        this.rrnCode = rrnCode;
    }

    public void setPayMethod(String payMethod) {
        this.payMethod = payMethod;
    }

    public void setMaskedBankAccountNumber(String maskedBankAccountNumber) {
        this.maskedBankAccountNumber = maskedBankAccountNumber;
    }

    public void setMaskedCardNumber(String maskedCardNumber) {
        this.maskedCardNumber = maskedCardNumber;
    }

    public void setUserMobileNo(String userMobileNo) {
        this.userMobileNo = userMobileNo;
    }

    public void setRefundType(String refundType) {
        this.refundType = refundType;
    }

    @Override
    public String toString() {
        return "RecoverChannelInfo{" + "esn='" + esn + '\'' + ", virtualPaymentAddress='" + virtualPaymentAddress
                + '\'' + ", serviceInstId='" + serviceInstId + '\'' + ", mbid='" + mbid + '\'' + ", issuingBankName='"
                + issuingBankName + '\'' + ", cardScheme='" + cardScheme + '\'' + ", rrnCode='" + rrnCode + '\''
                + ", payMethod='" + payMethod + '\'' + ", maskedBankAccountNumber='" + maskedBankAccountNumber + '\''
                + ", maskedCardNumber='" + maskedCardNumber + '\'' + ", userMobileNo='" + userMobileNo + '\''
                + ", refundType='" + refundType + '\'' + ", recoverSuccessTime='" + recoverSuccessTime + '\'' + '}';
    }
}

