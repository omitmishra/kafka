package com.paytm.pgplus.notificationadapter.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class JsonMapper {
    private static final Logger log= LoggerFactory.getLogger(JsonMapper.class);
    private static ObjectMapper objectMapper = new ObjectMapper();
    static {
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY,true);

    }
    public static <T> T mapJsonToObject(final String jsonObject, final Class<T> clazz) throws JsonProcessingException {
        return objectMapper.readValue(jsonObject, clazz);
    }

    public static String mapObjectToJson(final Object object) throws JsonProcessingException {
        if (object != null) {
            try {
                final String resultString = objectMapper.writeValueAsString(object);
                return resultString;
            } catch (Exception e){
                log.error("Some exception occurred in mapObjectToJson", e);
            }
        }
        return null;
    }

}

