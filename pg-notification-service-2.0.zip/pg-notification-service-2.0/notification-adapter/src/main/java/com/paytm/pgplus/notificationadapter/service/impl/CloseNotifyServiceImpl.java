package com.paytm.pgplus.notificationadapter.service.impl;

import com.paytm.pg.common.structures.PayOptionDetailDTO;
import com.paytm.pg.common.structures.PaymentViewDTO;
import com.paytm.pg.dto.acquiring.CloseNotifyDTO;
import com.paytm.pgplus.notificationadapter.config.ApplicationConfig;
import com.paytm.pgplus.notificationadapter.helper.AdapterThreadContextHelper;
import com.paytm.pgplus.notificationadapter.helper.DateTimeFormatter;
import com.paytm.pgplus.notificationadapter.helper.JsonMapper;
import com.paytm.pgplus.notificationadapter.helper.PayloadHelperService;
import com.paytm.pgplus.notificationadapter.http.service.impl.AdapterClientImpl;
import com.paytm.pgplus.notificationadapter.model.Money;
import com.paytm.pgplus.notificationadapter.model.PaymentView;
import com.paytm.pgplus.notificationadapter.model.closeNotify.CloseNotifyRequestBody;
import com.paytm.pgplus.notificationadapter.model.paymentNotify.PayChannelInfo;
import com.paytm.pgplus.notificationadapter.model.paymentNotify.PayOptionInfo;
import com.paytm.pgplus.notificationadapter.service.IProcessNotificationAdapterService;

import com.paytm.pgplus.notificationadapter.util.NotificationAdapterConstants;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service("closeNotifyServiceImpl")
public class CloseNotifyServiceImpl implements IProcessNotificationAdapterService {

    private static final Logger log= LoggerFactory.getLogger(CloseNotifyServiceImpl.class);

    @Autowired
    AdapterClientImpl adapterClientImpl;

    @Autowired
    PayloadHelperService payloadHelperService;

    @Autowired
    ApplicationConfig applicationConfig;
    
    @Override
    public Runnable createNotifierJob(String kafkaPayload) {
        return new Runnable() {
            @Override
            public void run() {
                if (null != kafkaPayload){
                    try {
                        ThreadContext.clearAll();
                        CloseNotifyRequestBody body = processCloseNotifyDTO(kafkaPayload);
                        AdapterThreadContextHelper.setThreadContext(body.getAcquirementId(), body.getMerchantTransId(), "CloseNotify");
                        if(applicationConfig.isCheckForShadowMerchant() && body.getMerchantId().matches(".*[A-Za-z].*") && body.getMerchantId().matches(".*[0-9].*") && body.getMerchantId().matches("[A-Za-z0-9]*"))
                        {
                            log.info("Shadow Request received for mid:{}",body.getMerchantId());
                        }else {
                            adapterClientImpl.processCloseNotify(payloadHelperService.getCloseNotifyPayload(body));
                        }
                    } catch (Exception e) {
                        log.error("Some Exception {} occurred during mapping of closeNotifyDTO to closeNotifyRequestBody for payload: {}", e, kafkaPayload);
                    }
                } else {
                    log.error("Payload can't be null for closeNotify!!");
                }
            }
        };
    }

    private CloseNotifyRequestBody processCloseNotifyDTO(String payload) throws Exception{
        CloseNotifyRequestBody closeNotifyRequestBody = new CloseNotifyRequestBody();
        try {
            CloseNotifyDTO closeNotifyDTO = JsonMapper.mapJsonToObject(payload, CloseNotifyDTO.class);

            closeNotifyRequestBody.setAcquirementId(closeNotifyDTO.getAcquirementId());
            closeNotifyRequestBody.setMerchantTransId(closeNotifyDTO.getMerchantTransId());
            if(StringUtils.isNotBlank(closeNotifyDTO.getClosedTime())){
                closeNotifyRequestBody.setClosedTime(DateTimeFormatter.getISO861DateTimeStringWithoutMillis(closeNotifyDTO.getClosedTime()));
            } else {
                throw new Exception("closedTime cannot be blank !");
            }
            closeNotifyRequestBody.setCloseResult(closeNotifyDTO.getCloseResult());
            if(null == closeNotifyDTO.getAdditionalMetaInfo()){
                throw new Exception("Additional Meta info not Found!");
            }
            String merchantId=closeNotifyDTO.getAdditionalMetaInfo().get(NotificationAdapterConstants.ALIPAY_MID);

            if(StringUtils.isBlank(merchantId)){
                throw new Exception("Merchant Id can't be blank!");
            }
            closeNotifyRequestBody.setMerchantId(merchantId);

            Money orderAmount = new Money();
            if (closeNotifyDTO.getOrderAmount() != null){
                orderAmount.setValue(String.valueOf(closeNotifyDTO.getOrderAmount().getCent()));
                if (closeNotifyDTO.getOrderAmount().getCurrency() != null)
                    orderAmount.setCurrency(closeNotifyDTO.getOrderAmount().getCurrency().getCurrencyCode());
            }
            closeNotifyRequestBody.setOrderAmount(orderAmount);

            if (StringUtils.isNotBlank(closeNotifyDTO.getCreateOrderTime())){
                closeNotifyRequestBody.setCreateOrderTime(DateTimeFormatter.getISO861DateTimeStringWithoutMillis(closeNotifyDTO.getCreateOrderTime()));
            } else {
                throw new Exception("createOrderTime cannot be blank !");
            }
            closeNotifyRequestBody.setOrderExtendInfo(closeNotifyDTO.getOrderExtendInfo());
            closeNotifyRequestBody.setProductCode(closeNotifyDTO.getProductCode());
            //This value is coming as empty map in UPI_PUSH case
            closeNotifyRequestBody.setOrderModifyExtendInfo(Collections.EMPTY_MAP.toString());
            //orderPricingInfo not coming in UPI_PUSH
            closeNotifyRequestBody.setAcquireMode(closeNotifyDTO.getAcquireMode());
            if (closeNotifyDTO.getPaymentViews() != null && checkPaidTime(closeNotifyDTO)){
                setPaymentViews(closeNotifyRequestBody, closeNotifyDTO);
            }
            closeNotifyRequestBody.setCloseSource(closeNotifyDTO.getCloseSource());
            closeNotifyRequestBody.setCloseReason(closeNotifyDTO.getCloseReason());
            //body = JsonMapper.mapObjectToJson(closeNotifyRequestBody);
        } catch (Exception e) {
            throw e;
        }
        return closeNotifyRequestBody;
    }

    private boolean checkPaidTime(CloseNotifyDTO closeNotifyDTO){
        for(PaymentViewDTO paymentViewDTO: closeNotifyDTO.getPaymentViews()){
            String paidTime=paymentViewDTO.getPaidTime();
            if(StringUtils.isBlank(paidTime)) {
                log.info("Got paid time blank for TID :{}", closeNotifyDTO.getAcquirementId());
                return false;
            }
        }
        return true;
    }
    private void setPaymentViews(CloseNotifyRequestBody closeNotifyRequestBody, CloseNotifyDTO closeNotifyDTO) throws Exception{
        try{
            List<PaymentView> paymentViews = new ArrayList<>();
            for(PaymentViewDTO paymentViewDTO : closeNotifyDTO.getPaymentViews()){
                PaymentView paymentView = new PaymentView();
                paymentView.setCashierRequestId(paymentViewDTO.getCashierRequestId());
                paymentView.setPaidTime(DateTimeFormatter.getISO861DateTimeStringWithoutMillis(paymentViewDTO.getPaidTime()));

                paymentView.setRevoked(paymentViewDTO.isRevoked());
                paymentView.setPayRequestExtendInfo(paymentViewDTO.getPayRequestExtendInfo());
                paymentView.setExtendInfo(paymentViewDTO.getExtendInfo());
                if (CollectionUtils.isNotEmpty(paymentViewDTO.getPayOptionInfos())){
                    setPayOptionInfos(paymentView, paymentViewDTO.getPayOptionInfos());
                }
                paymentViews.add(paymentView);
            }
            closeNotifyRequestBody.setPaymentViews(paymentViews);
        } catch (Exception e){
            log.error("Some exception occurred in setPaymentViews", e);
            throw e;
        }
    }

    private void setPayOptionInfos(PaymentView paymentView, List<PayOptionDetailDTO> payOptionInfosDTO) throws Exception{
        try{
            List<PayOptionInfo> payOptionInfos = new ArrayList<>();
            for (PayOptionDetailDTO payOptionDetailDTO : payOptionInfosDTO){
                PayOptionInfo payOptionInfo = new PayOptionInfo();
                payOptionInfo.setPayMethod(payOptionDetailDTO.getPayMethod());
                payOptionInfo.setPayOptionBillExtendInfo(payOptionDetailDTO.getPayOptionBillExtendInfo());

                Money payAmount = new Money();
                if(payOptionDetailDTO.getPayAmount()!=null){
                    if(payOptionDetailDTO.getPayAmount().getCurrency()!=null)
                        payAmount.setCurrency(payOptionDetailDTO.getPayAmount().getCurrency().getCurrencyCode());
                    payAmount.setValue(String.valueOf(payOptionDetailDTO.getPayAmount().getCent()));
                }

                payOptionInfo.setPayAmount(payAmount);

                Money transAmount = new Money();
                if(payOptionDetailDTO.getTransAmount()!=null){
                    if(payOptionDetailDTO.getTransAmount().getCurrency()!=null)
                        transAmount.setCurrency(payOptionDetailDTO.getTransAmount().getCurrency().getCurrencyCode());
                    transAmount.setValue(String.valueOf(payOptionDetailDTO.getTransAmount().getCent()));
                }

                payOptionInfo.setTransAmount(transAmount);

                //chargeAmount not in scope
                //revoked to be clarified
                payOptionInfo.setExtendInfo(payOptionDetailDTO.getExtendInfo());
                Money chargeAmount=new Money();
                chargeAmount.setCurrency("INR");
                chargeAmount.setValue("0");
                payOptionInfo.setChargeAmount(chargeAmount);
                PayChannelInfo payChannelInfo = new PayChannelInfo();
                payChannelInfo.setVirtualPaymentAddr(payOptionDetailDTO.getPayChannelInfo().getVirtualPaymentAddr());
                payChannelInfo.setPayerVpaCustomerId(payOptionDetailDTO.getPayChannelInfo().getPayerVpaCustomerId());
                payChannelInfo.setPayOption(payOptionDetailDTO.getPayChannelInfo().getPayOption());
                payOptionInfo.setPayChannelInfo(payChannelInfo);
                //dccPaymentInfo not needed for UPI_PUSH but needed in general
                payOptionInfos.add(payOptionInfo);
            }
            PayOptionInfo[] PayOptionInfoArr = payOptionInfos.stream().toArray(n -> new PayOptionInfo[n]);
            paymentView.setPayOptionInfos(PayOptionInfoArr);
        } catch (Exception e){
            log.error("Some exception occurred in setPayOptionInfos", e);
            throw e;
        }
    }
}
