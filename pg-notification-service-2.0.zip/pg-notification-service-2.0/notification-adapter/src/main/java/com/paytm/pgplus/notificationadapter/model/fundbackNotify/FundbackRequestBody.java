package com.paytm.pgplus.notificationadapter.model.fundbackNotify;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pg.common.structures.ResultInfo;
import com.paytm.pgplus.notificationadapter.model.AcquirementRequestBody;
import com.paytm.pgplus.notificationadapter.model.InputUserInfo;
import com.paytm.pgplus.notificationadapter.model.Money;
import com.paytm.pgplus.notificationadapter.model.paymentNotify.RefundChannelInfo;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FundbackRequestBody extends AcquirementRequestBody {

    /**
     * Serial version UID
     */
    private static final long serialVersionUID = 1L;

    @Length(max = 1024, message = "fundBackReason maximum length 1024")
    private String fundBackReason;

    /**
     * refund destination
     */
    @NotBlank(message = "refund destination cannot be null")
    private String destination;

    /**
     * channel information
     */
    private List<RefundChannelInfo> fundBackChannelInfoList;

    /**
     * merchant's name
     *
     */
    private String merchantName;

    /**
     * Result info
     */
    @NotNull(message = "resultInfo cannot be null")
    private ResultInfo resultInfo;

    /**
     * order extend info
     */
    @Length(max = 4096, message = "exceed orderExtendInfo maximum length 4096")
    private String orderExtendInfo;

    /**
     * the order amount
     */
    @NotNull(message = "orderAmount cannot be null")
    private Money orderAmount;

    /**
     * merchant id
     */
    @NotBlank(message = "merchantId cannot be blank")
    @Length(max = 32, message = "exceed merchantId maximum length 32")
    private String merchantId;

    /**
     * the product code
     */
    @NotBlank(message = "productCode cannot be blank")
    @Length(max = 64, message = "exceed productCode maximum length 64")
    private String productCode;

    /**
     * contractId belong to the merchant's order
     */
    @NotBlank(message = "contractId cannot be blank")
    @Length(max = 64, message = "exceed contractId maximum length 64")
    private String contractId;

    /**
     * create order time
     */
    @NotNull(message = "createOrderTime cannot be empty")
    private String createOrderTime;

    private String pwpCategory;

    /**
     * buyerInfo
     */
    private InputUserInfo buyerInfo;

    public String getFundBackReason() {
        return fundBackReason;
    }

    public String getDestination() {
        return destination;
    }

    public List<RefundChannelInfo> getFundBackChannelInfoList() {
        return fundBackChannelInfoList;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public ResultInfo getResultInfo() {
        return resultInfo;
    }

    public String getOrderExtendInfo() {
        return orderExtendInfo;
    }

    public Money getOrderAmount() {
        return orderAmount;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public String getProductCode() {
        return productCode;
    }

    public String getContractId() {
        return contractId;
    }

    public String getCreateOrderTime() {
        return createOrderTime;
    }

    public InputUserInfo getBuyerInfo() {
        return buyerInfo;
    }

    public void setFundBackReason(String fundBackReason) {
        this.fundBackReason = fundBackReason;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public void setFundBackChannelInfoList(List<RefundChannelInfo> fundBackChannelInfoList) {
        this.fundBackChannelInfoList = fundBackChannelInfoList;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public void setResultInfo(ResultInfo resultInfo) {
        this.resultInfo = resultInfo;
    }

    public void setOrderExtendInfo(String orderExtendInfo) {
        this.orderExtendInfo = orderExtendInfo;
    }

    public void setOrderAmount(Money orderAmount) {
        this.orderAmount = orderAmount;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public void setCreateOrderTime(String createOrderTime) {
        this.createOrderTime = createOrderTime;
    }

    public void setBuyerInfo(InputUserInfo buyerInfo) {
        this.buyerInfo = buyerInfo;
    }

    @Override
    public String toString() {
        return "FundbackRequestBody{" + "fundBackReason='" + fundBackReason + '\'' + ", destination='" + destination
                + '\'' + ", fundBackChannelInfoList=" + fundBackChannelInfoList + ", merchantName='" + merchantName
                + '\'' + ", resultInfo=" + resultInfo + ", orderExtendInfo='" + orderExtendInfo + '\''
                + ", bizExtendInfo='" + '\'' + ", extendInfo='" + '\'' + ", orderAmount=" + orderAmount
                + ", merchantId='" + merchantId + '\'' + ", productCode='" + productCode + '\'' + ", contractId='"
                + contractId + '\'' + ", createOrderTime='" + createOrderTime + '\'' + ", paidTime='" + '\''
                + ", buyerInfo=" + buyerInfo + ", pwpCategory=" + pwpCategory + '}';
    }

    public void setPwpCategory(String pwpCategory) {
        this.pwpCategory = pwpCategory;
    }

    public String getPwpCategory() {
        return pwpCategory;
    }
}
