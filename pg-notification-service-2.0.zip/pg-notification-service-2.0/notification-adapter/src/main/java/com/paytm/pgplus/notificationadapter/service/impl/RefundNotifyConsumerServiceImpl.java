package com.paytm.pgplus.notificationadapter.service.impl;

import com.paytm.pgplus.notificationadapter.pool.IExecutorServicePool;
import com.paytm.pgplus.notificationadapter.service.BusinessProcessor;
import com.paytm.pgplus.notificationadapter.service.IProcessNotificationAdapterService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service(value = "refundNotifyConsumerServiceImpl")
public class RefundNotifyConsumerServiceImpl implements BusinessProcessor {
    private static final Logger LOGGER = LoggerFactory.getLogger(RefundNotifyConsumerServiceImpl.class.getName());

    @Autowired
    protected IExecutorServicePool executorServicePool;

    @Autowired
    @Qualifier("refundNotifyServiceImpl")
    private IProcessNotificationAdapterService refundNotifyService;

    @Override
    public void process(String data){
        try{
            final Runnable notifierJob = refundNotifyService.createNotifierJob(data);

            executorServicePool.submitJob(notifierJob);

        } catch (Exception ex){
            LOGGER.error("Exception occurred :{} not able to submit job for  refundNotifyService:{}",ex,data);

        }
    }
}
