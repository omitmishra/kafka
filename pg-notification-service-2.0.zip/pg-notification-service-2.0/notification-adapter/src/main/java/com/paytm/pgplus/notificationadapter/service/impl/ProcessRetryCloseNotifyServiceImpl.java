package com.paytm.pgplus.notificationadapter.service.impl;

import com.paytm.pgplus.notificationadapter.helper.AdapterThreadContextHelper;
import com.paytm.pgplus.notificationadapter.http.service.impl.AdapterClientImpl;
import com.paytm.pgplus.notificationadapter.service.IProcessNotificationAdapterService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("processRetryCloseNotifyServiceImpl")
public class ProcessRetryCloseNotifyServiceImpl implements IProcessNotificationAdapterService {

    private static final Logger log= LoggerFactory.getLogger(ProcessRetryCloseNotifyServiceImpl.class);

    @Autowired
    AdapterClientImpl adapterClient;

    @Override
    public Runnable createNotifierJob(String closeNotifyRequestBody) {

        return new Runnable() {
            @Override
            public void run() {
                try {
                    AdapterThreadContextHelper.setThreadContextForRetry(closeNotifyRequestBody,"CloseNotifyRetry");
                    adapterClient.processRetryCloseNotify(closeNotifyRequestBody);
                }catch (Exception e){
                    log.error("Exception : {} occurred while processing closeNotify retry request:{}",e.getMessage(),closeNotifyRequestBody);
                }
            }
        };


    }
}
