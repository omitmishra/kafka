package com.paytm.pgplus.notificationadapter.http.service.impl;

import com.paytm.pgplus.notificationadapter.http.enums.ServiceUrl;
import com.paytm.pgplus.notificationadapter.http.service.IUrlService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class BaseUrlServiceImpl implements IUrlService {

    @Value("${adapter.core.base.url}")
    String baseUrl;

    @Override
    public String getUrl(ServiceUrl serviceUrl) {
        return this.baseUrl + serviceUrl.getFunctionalUrl();
    }
}
