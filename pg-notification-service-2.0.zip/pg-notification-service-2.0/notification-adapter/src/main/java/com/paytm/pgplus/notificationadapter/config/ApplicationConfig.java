package com.paytm.pgplus.notificationadapter.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.List;


@Configuration
public class ApplicationConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationConfig.class);


    @Value("${min.pool.size}")
    private int minPoolSize;

    @Value("${max.pool.size}")
    private int maxPoolSize;

    @Value("${keep.alive.time}")
    private int keepAliveTimeInMillis;

    @Value("${shutdown.wait.time}")
    private int appShutDownTimeInMillis;

    @Value("${retry.count}")
    private int retryCount;

    @Value("${blocking.queue.pool.size}")
    private int blockingQueuePoolSize;

    @Value("${checkForShadowMerchant}")
    private boolean checkForShadowMerchant;

    @Value("${web.client.timeout}")
    private int webClientTimeOut;


    public int getMinPoolSize() {
        return minPoolSize;
    }

    public int getWebClientTimeOut() {
        return webClientTimeOut;
    }

    public int getMaxPoolSize() {
        return maxPoolSize;
    }

    public int getKeepAliveTimeInMillis() {
        return keepAliveTimeInMillis;
    }

    public int getAppShutDownTimeInMillis() {
        return appShutDownTimeInMillis;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public int getBlockingQueuePoolSize() {
        return blockingQueuePoolSize;
    }

    public boolean isCheckForShadowMerchant() {
        return checkForShadowMerchant;
    }


}
