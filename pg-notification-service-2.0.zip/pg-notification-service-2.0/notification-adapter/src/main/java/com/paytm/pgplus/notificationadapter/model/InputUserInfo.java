package com.paytm.pgplus.notificationadapter.model;

/*
 * This File is the sole property of Paytm(One97 Communications Limited)
 */

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Length;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class InputUserInfo implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -5573513068842667281L;

    @Length(max = 32, message = "user id cannot be more than 32 characters")
    private String userId;

    @Length(max = 32, message = "external user id cannot be more than 32 characters")
    private String externalUserId;
    private String externalUserType;
    private String nickname = "";

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @return the externalUserId
     */
    public String getExternalUserId() {
        return externalUserId;
    }

    /**
     * @return the externalUserType
     */
    public String getExternalUserType() {
        return externalUserType;
    }

    /**
     * @return the nickname
     */
    public String getNickname() {
        return nickname;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setExternalUserId(String externalUserId) {
        this.externalUserId = externalUserId;
    }

    public void setExternalUserType(String externalUserType) {
        this.externalUserType = externalUserType;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("InputUserInfo [userId=").append(userId).append(", externalUserId=").append(externalUserId)
                .append(", externalUserType=").append(externalUserType).append(", nickname=").append(nickname)
                .append("]");
        return builder.toString();
    }

}

