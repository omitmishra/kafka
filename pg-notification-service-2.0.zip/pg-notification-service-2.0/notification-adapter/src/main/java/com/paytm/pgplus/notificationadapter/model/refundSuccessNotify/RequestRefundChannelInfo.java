package com.paytm.pgplus.notificationadapter.model.refundSuccessNotify;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestRefundChannelInfo implements Serializable {

    private static final long serialVersionUID = 1L;
    private String maskedBankAccountNumber;
    private String virtualPaymentAddress;
    private String issuingBankName;
    private String ifscCode;

    public String getMaskedBankAccountNumber() {
        return maskedBankAccountNumber;
    }

    public void setMaskedBankAccountNumber(String maskedBankAccountNumber) {
        this.maskedBankAccountNumber = maskedBankAccountNumber;
    }

    public String getVirtualPaymentAddress() {
        return virtualPaymentAddress;
    }

    public void setVirtualPaymentAddress(String virtualPaymentAddress) {
        this.virtualPaymentAddress = virtualPaymentAddress;
    }

    public String getIssuingBankName() {
        return issuingBankName;
    }

    public void setIssuingBankName(String issuingBankName) {
        this.issuingBankName = issuingBankName;
    }

    public String getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

}

